export declare const name = "@azure/msal-angular";
export declare const version = "3.0.0-beta.1";
