/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import { Injectable } from '@angular/core';
import { NavigationClient, UrlString, } from '@azure/msal-browser';
import * as i0 from "@angular/core";
import * as i1 from "./msal.service";
import * as i2 from "@angular/router";
import * as i3 from "@angular/common";
/**
 * Custom navigation used for Angular client-side navigation.
 * See performance doc for details:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/tree/dev/lib/msal-angular/docs/performance.md
 */
export class MsalCustomNavigationClient extends NavigationClient {
    constructor(authService, router, location) {
        super();
        this.authService = authService;
        this.router = router;
        this.location = location;
    }
    async navigateInternal(url, options) {
        this.authService.getLogger().trace('MsalCustomNavigationClient called');
        this.authService
            .getLogger()
            .verbose('MsalCustomNavigationClient - navigating');
        this.authService
            .getLogger()
            .verbosePii(`MsalCustomNavigationClient - navigating to url: ${url}`);
        // Prevent hash clearing from causing an issue with Client-side navigation after redirect is handled
        if (options.noHistory) {
            return super.navigateInternal(url, options);
        }
        else {
            // Normalizing newUrl if no query string
            const urlComponents = new UrlString(url).getUrlComponents();
            const newUrl = urlComponents.QueryString
                ? `${urlComponents.AbsolutePath}?${urlComponents.QueryString}`
                : this.location.normalize(urlComponents.AbsolutePath);
            this.router.navigateByUrl(newUrl, { replaceUrl: options.noHistory });
        }
        return Promise.resolve(options.noHistory);
    }
}
MsalCustomNavigationClient.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalCustomNavigationClient, deps: [{ token: i1.MsalService }, { token: i2.Router }, { token: i3.Location }], target: i0.ɵɵFactoryTarget.Injectable });
MsalCustomNavigationClient.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalCustomNavigationClient });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalCustomNavigationClient, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.MsalService }, { type: i2.Router }, { type: i3.Location }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNhbC5uYXZpZ2F0aW9uLmNsaWVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tc2FsLm5hdmlnYXRpb24uY2xpZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUVILE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHM0MsT0FBTyxFQUNMLGdCQUFnQixFQUVoQixTQUFTLEdBQ1YsTUFBTSxxQkFBcUIsQ0FBQzs7Ozs7QUFHN0I7Ozs7R0FJRztBQUVILE1BQU0sT0FBTywwQkFBMkIsU0FBUSxnQkFBZ0I7SUFDOUQsWUFDVSxXQUF3QixFQUN4QixNQUFjLEVBQ2QsUUFBa0I7UUFFMUIsS0FBSyxFQUFFLENBQUM7UUFKQSxnQkFBVyxHQUFYLFdBQVcsQ0FBYTtRQUN4QixXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsYUFBUSxHQUFSLFFBQVEsQ0FBVTtJQUc1QixDQUFDO0lBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUNwQixHQUFXLEVBQ1gsT0FBMEI7UUFFMUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsbUNBQW1DLENBQUMsQ0FBQztRQUV4RSxJQUFJLENBQUMsV0FBVzthQUNiLFNBQVMsRUFBRTthQUNYLE9BQU8sQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxXQUFXO2FBQ2IsU0FBUyxFQUFFO2FBQ1gsVUFBVSxDQUFDLG1EQUFtRCxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXhFLG9HQUFvRztRQUNwRyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUU7WUFDckIsT0FBTyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQzdDO2FBQU07WUFDTCx3Q0FBd0M7WUFDeEMsTUFBTSxhQUFhLEdBQUcsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUM1RCxNQUFNLE1BQU0sR0FBRyxhQUFhLENBQUMsV0FBVztnQkFDdEMsQ0FBQyxDQUFDLEdBQUcsYUFBYSxDQUFDLFlBQVksSUFBSSxhQUFhLENBQUMsV0FBVyxFQUFFO2dCQUM5RCxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3hELElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFFLFVBQVUsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztTQUN0RTtRQUNELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUMsQ0FBQzs7dUhBbENVLDBCQUEwQjsySEFBMUIsMEJBQTBCOzJGQUExQiwwQkFBMEI7a0JBRHRDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7XG4gIE5hdmlnYXRpb25DbGllbnQsXG4gIE5hdmlnYXRpb25PcHRpb25zLFxuICBVcmxTdHJpbmcsXG59IGZyb20gJ0BhenVyZS9tc2FsLWJyb3dzZXInO1xuaW1wb3J0IHsgTXNhbFNlcnZpY2UgfSBmcm9tICcuL21zYWwuc2VydmljZSc7XG5cbi8qKlxuICogQ3VzdG9tIG5hdmlnYXRpb24gdXNlZCBmb3IgQW5ndWxhciBjbGllbnQtc2lkZSBuYXZpZ2F0aW9uLlxuICogU2VlIHBlcmZvcm1hbmNlIGRvYyBmb3IgZGV0YWlsczpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9BenVyZUFEL21pY3Jvc29mdC1hdXRoZW50aWNhdGlvbi1saWJyYXJ5LWZvci1qcy90cmVlL2Rldi9saWIvbXNhbC1hbmd1bGFyL2RvY3MvcGVyZm9ybWFuY2UubWRcbiAqL1xuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIE1zYWxDdXN0b21OYXZpZ2F0aW9uQ2xpZW50IGV4dGVuZHMgTmF2aWdhdGlvbkNsaWVudCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgYXV0aFNlcnZpY2U6IE1zYWxTZXJ2aWNlLFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb25cbiAgKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIGFzeW5jIG5hdmlnYXRlSW50ZXJuYWwoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgb3B0aW9uczogTmF2aWdhdGlvbk9wdGlvbnNcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdGhpcy5hdXRoU2VydmljZS5nZXRMb2dnZXIoKS50cmFjZSgnTXNhbEN1c3RvbU5hdmlnYXRpb25DbGllbnQgY2FsbGVkJyk7XG5cbiAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgIC52ZXJib3NlKCdNc2FsQ3VzdG9tTmF2aWdhdGlvbkNsaWVudCAtIG5hdmlnYXRpbmcnKTtcbiAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgIC52ZXJib3NlUGlpKGBNc2FsQ3VzdG9tTmF2aWdhdGlvbkNsaWVudCAtIG5hdmlnYXRpbmcgdG8gdXJsOiAke3VybH1gKTtcblxuICAgIC8vIFByZXZlbnQgaGFzaCBjbGVhcmluZyBmcm9tIGNhdXNpbmcgYW4gaXNzdWUgd2l0aCBDbGllbnQtc2lkZSBuYXZpZ2F0aW9uIGFmdGVyIHJlZGlyZWN0IGlzIGhhbmRsZWRcbiAgICBpZiAob3B0aW9ucy5ub0hpc3RvcnkpIHtcbiAgICAgIHJldHVybiBzdXBlci5uYXZpZ2F0ZUludGVybmFsKHVybCwgb3B0aW9ucyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIE5vcm1hbGl6aW5nIG5ld1VybCBpZiBubyBxdWVyeSBzdHJpbmdcbiAgICAgIGNvbnN0IHVybENvbXBvbmVudHMgPSBuZXcgVXJsU3RyaW5nKHVybCkuZ2V0VXJsQ29tcG9uZW50cygpO1xuICAgICAgY29uc3QgbmV3VXJsID0gdXJsQ29tcG9uZW50cy5RdWVyeVN0cmluZ1xuICAgICAgICA/IGAke3VybENvbXBvbmVudHMuQWJzb2x1dGVQYXRofT8ke3VybENvbXBvbmVudHMuUXVlcnlTdHJpbmd9YFxuICAgICAgICA6IHRoaXMubG9jYXRpb24ubm9ybWFsaXplKHVybENvbXBvbmVudHMuQWJzb2x1dGVQYXRoKTtcbiAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlQnlVcmwobmV3VXJsLCB7IHJlcGxhY2VVcmw6IG9wdGlvbnMubm9IaXN0b3J5IH0pO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKG9wdGlvbnMubm9IaXN0b3J5KTtcbiAgfVxufVxuIl19