import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { NavigationClient, NavigationOptions } from '@azure/msal-browser';
import { MsalService } from './msal.service';
import * as i0 from "@angular/core";
/**
 * Custom navigation used for Angular client-side navigation.
 * See performance doc for details:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/tree/dev/lib/msal-angular/docs/performance.md
 */
export declare class MsalCustomNavigationClient extends NavigationClient {
    private authService;
    private router;
    private location;
    constructor(authService: MsalService, router: Router, location: Location);
    navigateInternal(url: string, options: NavigationOptions): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalCustomNavigationClient, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MsalCustomNavigationClient>;
}
