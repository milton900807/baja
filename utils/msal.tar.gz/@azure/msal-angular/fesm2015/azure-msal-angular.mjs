import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Inject, Optional, Component, NgModule } from '@angular/core';
import { WrapperSKU, InteractionStatus, EventMessageUtils, InteractionType, BrowserConfigurationAuthError, UrlString, BrowserUtils, StringUtils, NavigationClient } from '@azure/msal-browser';
import { from, ReplaySubject, Subject, BehaviorSubject, of, EMPTY } from 'rxjs';
import * as i3 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { map, concatMap, catchError, switchMap, take, filter } from 'rxjs/operators';
import * as i4 from '@angular/router';
import { __awaiter } from 'tslib';

/* eslint-disable header/header */
const name = "@azure/msal-angular";
const version = "3.0.0-beta.1";

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const MSAL_INSTANCE = new InjectionToken('MSAL_INSTANCE');
const MSAL_GUARD_CONFIG = new InjectionToken('MSAL_GUARD_CONFIG');
const MSAL_INTERCEPTOR_CONFIG = new InjectionToken('MSAL_INTERCEPTOR_CONFIG');
const MSAL_BROADCAST_CONFIG = new InjectionToken('MSAL_BROADCAST_CONFIG');

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class MsalService {
    constructor(instance, location) {
        this.instance = instance;
        this.location = location;
        const hash = this.location.path(true).split('#').pop();
        if (hash) {
            this.redirectHash = `#${hash}`;
        }
        this.instance.initializeWrapperLibrary(WrapperSKU.Angular, version);
    }
    initialize() {
        return from(this.instance.initialize());
    }
    acquireTokenPopup(request) {
        return from(this.instance.acquireTokenPopup(request));
    }
    acquireTokenRedirect(request) {
        return from(this.instance.acquireTokenRedirect(request));
    }
    acquireTokenSilent(silentRequest) {
        return from(this.instance.acquireTokenSilent(silentRequest));
    }
    handleRedirectObservable(hash) {
        return from(this.instance
            .initialize()
            .then(() => this.instance.handleRedirectPromise(hash || this.redirectHash)));
    }
    loginPopup(request) {
        return from(this.instance.loginPopup(request));
    }
    loginRedirect(request) {
        return from(this.instance.loginRedirect(request));
    }
    logout(logoutRequest) {
        return from(this.instance.logout(logoutRequest));
    }
    logoutRedirect(logoutRequest) {
        return from(this.instance.logoutRedirect(logoutRequest));
    }
    logoutPopup(logoutRequest) {
        return from(this.instance.logoutPopup(logoutRequest));
    }
    ssoSilent(request) {
        return from(this.instance.ssoSilent(request));
    }
    /**
     * Gets logger for msal-angular.
     * If no logger set, returns logger instance created with same options as msal-browser
     */
    getLogger() {
        if (!this.logger) {
            this.logger = this.instance.getLogger().clone(name, version);
        }
        return this.logger;
    }
    // Create a logger instance for msal-angular with the same options as msal-browser
    setLogger(logger) {
        this.logger = logger.clone(name, version);
        this.instance.setLogger(logger);
    }
}
MsalService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalService, deps: [{ token: MSAL_INSTANCE }, { token: i3.Location }], target: i0.ɵɵFactoryTarget.Injectable });
MsalService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalService, decorators: [{
            type: Injectable
        }], ctorParameters: function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [MSAL_INSTANCE]
                    }] }, { type: i3.Location }];
    } });

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class MsalBroadcastService {
    constructor(msalInstance, authService, msalBroadcastConfig) {
        this.msalInstance = msalInstance;
        this.authService = authService;
        this.msalBroadcastConfig = msalBroadcastConfig;
        // Make _msalSubject a ReplaySubject if configured to replay past events
        if (this.msalBroadcastConfig &&
            this.msalBroadcastConfig.eventsToReplay > 0) {
            this.authService
                .getLogger()
                .verbose(`BroadcastService - eventsToReplay set on BroadcastConfig, replaying the last ${this.msalBroadcastConfig.eventsToReplay} events`);
            this._msalSubject = new ReplaySubject(this.msalBroadcastConfig.eventsToReplay);
        }
        else {
            // Defaults to _msalSubject being a Subject
            this._msalSubject = new Subject();
        }
        this.msalSubject$ = this._msalSubject.asObservable();
        // InProgress as BehaviorSubject so most recent inProgress state will be available upon subscription
        this._inProgress = new BehaviorSubject(InteractionStatus.Startup);
        this.inProgress$ = this._inProgress.asObservable();
        this.msalInstance.addEventCallback((message) => {
            this._msalSubject.next(message);
            const status = EventMessageUtils.getInteractionStatusFromEvent(message, this._inProgress.value);
            if (status !== null) {
                this.authService
                    .getLogger()
                    .verbose(`BroadcastService - ${message.eventType} results in setting inProgress from ${this._inProgress.value} to ${status}`);
                this._inProgress.next(status);
            }
        });
    }
}
MsalBroadcastService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalBroadcastService, deps: [{ token: MSAL_INSTANCE }, { token: MsalService }, { token: MSAL_BROADCAST_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
MsalBroadcastService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalBroadcastService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalBroadcastService, decorators: [{
            type: Injectable
        }], ctorParameters: function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [MSAL_INSTANCE]
                    }] }, { type: MsalService }, { type: undefined, decorators: [{
                        type: Optional
                    }, {
                        type: Inject,
                        args: [MSAL_BROADCAST_CONFIG]
                    }] }];
    } });

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class MsalGuard {
    constructor(msalGuardConfig, msalBroadcastService, authService, location, router) {
        this.msalGuardConfig = msalGuardConfig;
        this.msalBroadcastService = msalBroadcastService;
        this.authService = authService;
        this.location = location;
        this.router = router;
        // Subscribing so events in MsalGuard will set inProgress$ observable
        this.msalBroadcastService.inProgress$.subscribe();
    }
    /**
     * Parses url string to UrlTree
     * @param url
     */
    parseUrl(url) {
        return this.router.parseUrl(url);
    }
    /**
     * Builds the absolute url for the destination page
     * @param path Relative path of requested page
     * @returns Full destination url
     */
    getDestinationUrl(path) {
        this.authService.getLogger().verbose('Guard - getting destination url');
        // Absolute base url for the application (default to origin if base element not present)
        const baseElements = document.getElementsByTagName('base');
        const baseUrl = this.location.normalize(baseElements.length ? baseElements[0].href : window.location.origin);
        // Path of page (including hash, if using hash routing)
        const pathUrl = this.location.prepareExternalUrl(path);
        // Hash location strategy
        if (pathUrl.startsWith('#')) {
            this.authService
                .getLogger()
                .verbose('Guard - destination by hash routing');
            return `${baseUrl}/${pathUrl}`;
        }
        /*
         * If using path location strategy, pathUrl will include the relative portion of the base path (e.g. /base/page).
         * Since baseUrl also includes /base, can just concatentate baseUrl + path
         */
        return `${baseUrl}${path}`;
    }
    /**
     * Interactively prompt the user to login
     * @param url Path of the requested page
     */
    loginInteractively(state) {
        const authRequest = typeof this.msalGuardConfig.authRequest === 'function'
            ? this.msalGuardConfig.authRequest(this.authService, state)
            : Object.assign({}, this.msalGuardConfig.authRequest);
        if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
            this.authService.getLogger().verbose('Guard - logging in by popup');
            return this.authService.loginPopup(authRequest).pipe(map((response) => {
                this.authService
                    .getLogger()
                    .verbose('Guard - login by popup successful, can activate, setting active account');
                this.authService.instance.setActiveAccount(response.account);
                return true;
            }));
        }
        this.authService.getLogger().verbose('Guard - logging in by redirect');
        const redirectStartPage = this.getDestinationUrl(state.url);
        return this.authService
            .loginRedirect(Object.assign({ redirectStartPage }, authRequest))
            .pipe(map(() => false));
    }
    /**
     * Helper which checks for the correct interaction type, prevents page with Guard to be set as redirect, and calls handleRedirectObservable
     * @param state
     */
    activateHelper(state) {
        if (this.msalGuardConfig.interactionType !== InteractionType.Popup &&
            this.msalGuardConfig.interactionType !== InteractionType.Redirect) {
            throw new BrowserConfigurationAuthError('invalid_interaction_type', 'Invalid interaction type provided to MSAL Guard. InteractionType.Popup or InteractionType.Redirect must be provided in the MsalGuardConfiguration');
        }
        this.authService.getLogger().verbose('MSAL Guard activated');
        /*
         * If a page with MSAL Guard is set as the redirect for acquireTokenSilent,
         * short-circuit to prevent redirecting or popups.
         */
        if (typeof window !== 'undefined') {
            if (UrlString.hashContainsKnownProperties(window.location.hash) &&
                BrowserUtils.isInIframe() &&
                !this.authService.instance.getConfiguration().system
                    .allowRedirectInIframe) {
                this.authService
                    .getLogger()
                    .warning('Guard - redirectUri set to page with MSAL Guard. It is recommended to not set redirectUri to a page that requires authentication.');
                return of(false);
            }
        }
        else {
            this.authService
                .getLogger()
                .info('Guard - window is undefined, MSAL does not support server-side token acquisition');
            return of(true);
        }
        /**
         * If a loginFailedRoute is set in the config, set this as the loginFailedRoute
         */
        if (this.msalGuardConfig.loginFailedRoute) {
            this.loginFailedRoute = this.parseUrl(this.msalGuardConfig.loginFailedRoute);
        }
        // Capture current path before it gets changed by handleRedirectObservable
        const currentPath = this.location.path(true);
        return this.authService.initialize().pipe(concatMap(() => {
            return this.authService.handleRedirectObservable();
        }), concatMap(() => {
            if (!this.authService.instance.getAllAccounts().length) {
                if (state) {
                    this.authService
                        .getLogger()
                        .verbose('Guard - no accounts retrieved, log in required to activate');
                    return this.loginInteractively(state);
                }
                this.authService
                    .getLogger()
                    .verbose('Guard - no accounts retrieved, no state, cannot load');
                return of(false);
            }
            this.authService
                .getLogger()
                .verbose('Guard - at least 1 account exists, can activate or load');
            // Prevent navigating the app to /#code= or /code=
            if (state) {
                /*
                 * Path routing:
                 * state.url: /#code=...
                 * state.root.fragment: code=...
                 */
                /*
                 * Hash routing:
                 * state.url: /code
                 * state.root.fragment: null
                 */
                const urlContainsCode = this.includesCode(state.url);
                const fragmentContainsCode = !!state.root &&
                    !!state.root.fragment &&
                    this.includesCode(`#${state.root.fragment}`);
                const hashRouting = this.location.prepareExternalUrl(state.url).indexOf('#') === 0;
                // Ensure code parameter is in fragment (and not in query parameter), or that hash hash routing is used
                if (urlContainsCode && (fragmentContainsCode || hashRouting)) {
                    this.authService
                        .getLogger()
                        .info('Guard - Hash contains known code response, stopping navigation.');
                    // Path routing (navigate to current path without hash)
                    if (currentPath.indexOf('#') > -1) {
                        return of(this.parseUrl(this.location.path()));
                    }
                    // Hash routing (navigate to root path)
                    return of(this.parseUrl(''));
                }
            }
            return of(true);
        }), catchError((error) => {
            this.authService
                .getLogger()
                .error('Guard - error while logging in, unable to activate');
            this.authService
                .getLogger()
                .errorPii(`Guard - error: ${error.message}`);
            /**
             * If a loginFailedRoute is set, checks to see if state is passed before returning route
             */
            if (this.loginFailedRoute && state) {
                this.authService
                    .getLogger()
                    .verbose('Guard - loginFailedRoute set, redirecting');
                return of(this.loginFailedRoute);
            }
            return of(false);
        }));
    }
    includesCode(path) {
        return ((path.lastIndexOf('/code') > -1 &&
            path.lastIndexOf('/code') === path.length - '/code'.length) || // path.endsWith("/code")
            path.indexOf('#code=') > -1 ||
            path.indexOf('&code=') > -1);
    }
    canActivate(route, state) {
        this.authService.getLogger().verbose('Guard - canActivate');
        return this.activateHelper(state);
    }
    canActivateChild(route, state) {
        this.authService.getLogger().verbose('Guard - canActivateChild');
        return this.activateHelper(state);
    }
    canMatch() {
        this.authService.getLogger().verbose('Guard - canLoad');
        return this.activateHelper();
    }
}
MsalGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalGuard, deps: [{ token: MSAL_GUARD_CONFIG }, { token: MsalBroadcastService }, { token: MsalService }, { token: i3.Location }, { token: i4.Router }], target: i0.ɵɵFactoryTarget.Injectable });
MsalGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalGuard });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalGuard, decorators: [{
            type: Injectable
        }], ctorParameters: function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [MSAL_GUARD_CONFIG]
                    }] }, { type: MsalBroadcastService }, { type: MsalService }, { type: i3.Location }, { type: i4.Router }];
    } });

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class MsalInterceptor {
    constructor(msalInterceptorConfig, authService, location, msalBroadcastService, 
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/explicit-module-boundary-types
    document) {
        this.msalInterceptorConfig = msalInterceptorConfig;
        this.authService = authService;
        this.location = location;
        this.msalBroadcastService = msalBroadcastService;
        this._document = document;
    }
    intercept(req, // eslint-disable-line @typescript-eslint/no-explicit-any
    next
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ) {
        if (this.msalInterceptorConfig.interactionType !== InteractionType.Popup &&
            this.msalInterceptorConfig.interactionType !== InteractionType.Redirect) {
            throw new BrowserConfigurationAuthError('invalid_interaction_type', 'Invalid interaction type provided to MSAL Interceptor. InteractionType.Popup, InteractionType.Redirect must be provided in the msalInterceptorConfiguration');
        }
        this.authService.getLogger().verbose('MSAL Interceptor activated');
        const scopes = this.getScopesForEndpoint(req.url, req.method);
        // If no scopes for endpoint, does not acquire token
        if (!scopes || scopes.length === 0) {
            this.authService
                .getLogger()
                .verbose('Interceptor - no scopes for endpoint');
            return next.handle(req);
        }
        // Sets account as active account or first account
        let account;
        if (!!this.authService.instance.getActiveAccount()) {
            this.authService
                .getLogger()
                .verbose('Interceptor - active account selected');
            account = this.authService.instance.getActiveAccount();
        }
        else {
            this.authService
                .getLogger()
                .verbose('Interceptor - no active account, fallback to first account');
            account = this.authService.instance.getAllAccounts()[0];
        }
        const authRequest = typeof this.msalInterceptorConfig.authRequest === 'function'
            ? this.msalInterceptorConfig.authRequest(this.authService, req, {
                account: account,
            })
            : Object.assign(Object.assign({}, this.msalInterceptorConfig.authRequest), { account });
        this.authService
            .getLogger()
            .info(`Interceptor - ${scopes.length} scopes found for endpoint`);
        this.authService
            .getLogger()
            .infoPii(`Interceptor - [${scopes}] scopes found for ${req.url}`);
        return this.acquireToken(authRequest, scopes, account).pipe(switchMap((result) => {
            this.authService
                .getLogger()
                .verbose('Interceptor - setting authorization headers');
            const headers = req.headers.set('Authorization', `Bearer ${result.accessToken}`);
            const requestClone = req.clone({ headers });
            return next.handle(requestClone);
        }));
    }
    /**
     * Try to acquire token silently. Invoke interaction if acquireTokenSilent rejected with error or resolved with null access token
     * @param authRequest Request
     * @param scopes Array of scopes for the request
     * @param account Account
     * @returns Authentication result
     */
    acquireToken(authRequest, scopes, account) {
        // Note: For MSA accounts, include openid scope when calling acquireTokenSilent to return idToken
        return this.authService
            .acquireTokenSilent(Object.assign(Object.assign({}, authRequest), { scopes, account }))
            .pipe(catchError(() => {
            this.authService
                .getLogger()
                .error('Interceptor - acquireTokenSilent rejected with error. Invoking interaction to resolve.');
            return this.msalBroadcastService.inProgress$.pipe(take(1), switchMap((status) => {
                if (status === InteractionStatus.None) {
                    return this.acquireTokenInteractively(authRequest, scopes);
                }
                return this.msalBroadcastService.inProgress$.pipe(filter((status) => status === InteractionStatus.None), take(1), switchMap(() => this.acquireToken(authRequest, scopes, account)));
            }));
        }), switchMap((result) => {
            if (!result.accessToken) {
                this.authService
                    .getLogger()
                    .error('Interceptor - acquireTokenSilent resolved with null access token. Known issue with B2C tenants, invoking interaction to resolve.');
                return this.msalBroadcastService.inProgress$.pipe(filter((status) => status === InteractionStatus.None), take(1), switchMap(() => this.acquireTokenInteractively(authRequest, scopes)));
            }
            return of(result);
        }));
    }
    /**
     * Invoke interaction for the given set of scopes
     * @param authRequest Request
     * @param scopes Array of scopes for the request
     * @returns Result from the interactive request
     */
    acquireTokenInteractively(authRequest, scopes) {
        if (this.msalInterceptorConfig.interactionType === InteractionType.Popup) {
            this.authService
                .getLogger()
                .verbose('Interceptor - error acquiring token silently, acquiring by popup');
            return this.authService.acquireTokenPopup(Object.assign(Object.assign({}, authRequest), { scopes }));
        }
        this.authService
            .getLogger()
            .verbose('Interceptor - error acquiring token silently, acquiring by redirect');
        const redirectStartPage = window.location.href;
        this.authService.acquireTokenRedirect(Object.assign(Object.assign({}, authRequest), { scopes,
            redirectStartPage }));
        return EMPTY;
    }
    /**
     * Looks up the scopes for the given endpoint from the protectedResourceMap
     * @param endpoint Url of the request
     * @param httpMethod Http method of the request
     * @returns Array of scopes, or null if not found
     *
     */
    getScopesForEndpoint(endpoint, httpMethod) {
        this.authService
            .getLogger()
            .verbose('Interceptor - getting scopes for endpoint');
        // Ensures endpoints and protected resources compared are normalized
        const normalizedEndpoint = this.location.normalize(endpoint);
        const protectedResourcesArray = Array.from(this.msalInterceptorConfig.protectedResourceMap.keys());
        const matchingProtectedResources = this.matchResourcesToEndpoint(protectedResourcesArray, normalizedEndpoint);
        // Check absolute urls of resources first before checking relative to prevent incorrect matching where multiple resources have similar relative urls
        if (matchingProtectedResources.absoluteResources.length > 0) {
            return this.matchScopesToEndpoint(this.msalInterceptorConfig.protectedResourceMap, matchingProtectedResources.absoluteResources, httpMethod);
        }
        else if (matchingProtectedResources.relativeResources.length > 0) {
            return this.matchScopesToEndpoint(this.msalInterceptorConfig.protectedResourceMap, matchingProtectedResources.relativeResources, httpMethod);
        }
        return null;
    }
    /**
     * Finds resource endpoints that match request endpoint
     * @param protectedResourcesEndpoints
     * @param endpoint
     * @returns
     */
    matchResourcesToEndpoint(protectedResourcesEndpoints, endpoint) {
        const matchingResources = {
            absoluteResources: [],
            relativeResources: [],
        };
        protectedResourcesEndpoints.forEach((key) => {
            // Normalizes and adds resource to matchingResources.absoluteResources if key matches endpoint. StringUtils.matchPattern accounts for wildcards
            const normalizedKey = this.location.normalize(key);
            if (StringUtils.matchPattern(normalizedKey, endpoint)) {
                matchingResources.absoluteResources.push(key);
            }
            // Get url components for relative urls
            const absoluteKey = this.getAbsoluteUrl(key);
            const keyComponents = new UrlString(absoluteKey).getUrlComponents();
            const absoluteEndpoint = this.getAbsoluteUrl(endpoint);
            const endpointComponents = new UrlString(absoluteEndpoint).getUrlComponents();
            // Normalized key should include query strings if applicable
            const relativeNormalizedKey = keyComponents.QueryString
                ? `${keyComponents.AbsolutePath}?${keyComponents.QueryString}`
                : this.location.normalize(keyComponents.AbsolutePath);
            // Add resource to matchingResources.relativeResources if same origin, relativeKey matches endpoint, and is not empty
            if (keyComponents.HostNameAndPort === endpointComponents.HostNameAndPort &&
                StringUtils.matchPattern(relativeNormalizedKey, absoluteEndpoint) &&
                relativeNormalizedKey !== '' &&
                relativeNormalizedKey !== '/*') {
                matchingResources.relativeResources.push(key);
            }
        });
        return matchingResources;
    }
    /**
     * Transforms relative urls to absolute urls
     * @param url
     * @returns
     */
    getAbsoluteUrl(url) {
        const link = this._document.createElement('a');
        link.href = url;
        return link.href;
    }
    /**
     * Finds scopes from first matching endpoint with HTTP method that matches request
     * @param protectedResourceMap Protected resource map
     * @param endpointArray Array of resources that match request endpoint
     * @param httpMethod Http method of the request
     * @returns
     */
    matchScopesToEndpoint(protectedResourceMap, endpointArray, httpMethod) {
        const allMatchedScopes = [];
        // Check each matched endpoint for matching HttpMethod and scopes
        endpointArray.forEach((matchedEndpoint) => {
            const scopesForEndpoint = [];
            const methodAndScopesArray = protectedResourceMap.get(matchedEndpoint);
            // Return if resource is unprotected
            if (methodAndScopesArray === null) {
                allMatchedScopes.push(null);
                return;
            }
            methodAndScopesArray.forEach((entry) => {
                // Entry is either array of scopes or ProtectedResourceScopes object
                if (typeof entry === 'string') {
                    scopesForEndpoint.push(entry);
                }
                else {
                    // Ensure methods being compared are normalized
                    const normalizedRequestMethod = httpMethod.toLowerCase();
                    const normalizedResourceMethod = entry.httpMethod.toLowerCase();
                    // Method in protectedResourceMap matches request http method
                    if (normalizedResourceMethod === normalizedRequestMethod) {
                        // Validate if scopes comes null to unprotect the resource in a certain http method
                        if (entry.scopes === null) {
                            allMatchedScopes.push(null);
                        }
                        else {
                            entry.scopes.forEach((scope) => {
                                scopesForEndpoint.push(scope);
                            });
                        }
                    }
                }
            });
            // Only add to all scopes if scopes for endpoint and method is found
            if (scopesForEndpoint.length > 0) {
                allMatchedScopes.push(scopesForEndpoint);
            }
        });
        if (allMatchedScopes.length > 0) {
            if (allMatchedScopes.length > 1) {
                this.authService
                    .getLogger()
                    .warning('Interceptor - More than 1 matching scopes for endpoint found.');
            }
            // Returns scopes for first matching endpoint
            return allMatchedScopes[0];
        }
        return null;
    }
}
MsalInterceptor.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalInterceptor, deps: [{ token: MSAL_INTERCEPTOR_CONFIG }, { token: MsalService }, { token: i3.Location }, { token: MsalBroadcastService }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
MsalInterceptor.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalInterceptor });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [MSAL_INTERCEPTOR_CONFIG]
                    }] }, { type: MsalService }, { type: i3.Location }, { type: MsalBroadcastService }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [DOCUMENT]
                    }] }];
    } });

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class MsalRedirectComponent {
    constructor(authService) {
        this.authService = authService;
    }
    ngOnInit() {
        this.authService.getLogger().verbose('MsalRedirectComponent activated');
        this.authService.handleRedirectObservable().subscribe();
    }
}
MsalRedirectComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalRedirectComponent, deps: [{ token: MsalService }], target: i0.ɵɵFactoryTarget.Component });
MsalRedirectComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.7", type: MsalRedirectComponent, selector: "app-redirect", ngImport: i0, template: '', isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalRedirectComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-redirect',
                    template: '',
                }]
        }], ctorParameters: function () { return [{ type: MsalService }]; } });

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class MsalModule {
    static forRoot(msalInstance, guardConfig, interceptorConfig) {
        return {
            ngModule: MsalModule,
            providers: [
                {
                    provide: MSAL_INSTANCE,
                    useValue: msalInstance,
                },
                {
                    provide: MSAL_GUARD_CONFIG,
                    useValue: guardConfig,
                },
                {
                    provide: MSAL_INTERCEPTOR_CONFIG,
                    useValue: interceptorConfig,
                },
                MsalService,
            ],
        };
    }
}
MsalModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
MsalModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, declarations: [MsalRedirectComponent], imports: [CommonModule] });
MsalModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, providers: [MsalGuard, MsalBroadcastService], imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MsalRedirectComponent],
                    imports: [CommonModule],
                    providers: [MsalGuard, MsalBroadcastService],
                }]
        }] });

/**
 * Custom navigation used for Angular client-side navigation.
 * See performance doc for details:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/tree/dev/lib/msal-angular/docs/performance.md
 */
class MsalCustomNavigationClient extends NavigationClient {
    constructor(authService, router, location) {
        super();
        this.authService = authService;
        this.router = router;
        this.location = location;
    }
    navigateInternal(url, options) {
        const _super = Object.create(null, {
            navigateInternal: { get: () => super.navigateInternal }
        });
        return __awaiter(this, void 0, void 0, function* () {
            this.authService.getLogger().trace('MsalCustomNavigationClient called');
            this.authService
                .getLogger()
                .verbose('MsalCustomNavigationClient - navigating');
            this.authService
                .getLogger()
                .verbosePii(`MsalCustomNavigationClient - navigating to url: ${url}`);
            // Prevent hash clearing from causing an issue with Client-side navigation after redirect is handled
            if (options.noHistory) {
                return _super.navigateInternal.call(this, url, options);
            }
            else {
                // Normalizing newUrl if no query string
                const urlComponents = new UrlString(url).getUrlComponents();
                const newUrl = urlComponents.QueryString
                    ? `${urlComponents.AbsolutePath}?${urlComponents.QueryString}`
                    : this.location.normalize(urlComponents.AbsolutePath);
                this.router.navigateByUrl(newUrl, { replaceUrl: options.noHistory });
            }
            return Promise.resolve(options.noHistory);
        });
    }
}
MsalCustomNavigationClient.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalCustomNavigationClient, deps: [{ token: MsalService }, { token: i4.Router }, { token: i3.Location }], target: i0.ɵɵFactoryTarget.Injectable });
MsalCustomNavigationClient.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalCustomNavigationClient });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalCustomNavigationClient, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: MsalService }, { type: i4.Router }, { type: i3.Location }]; } });

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MSAL_BROADCAST_CONFIG, MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalBroadcastService, MsalCustomNavigationClient, MsalGuard, MsalInterceptor, MsalModule, MsalRedirectComponent, MsalService, version };
//# sourceMappingURL=azure-msal-angular.mjs.map
