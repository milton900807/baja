import { Location } from '@angular/common';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MsalService } from './msal.service';
import { MsalGuardConfiguration } from './msal.guard.config';
import { MsalBroadcastService } from './msal.broadcast.service';
import * as i0 from "@angular/core";
export declare class MsalGuard {
    private msalGuardConfig;
    private msalBroadcastService;
    private authService;
    private location;
    private router;
    private loginFailedRoute?;
    constructor(msalGuardConfig: MsalGuardConfiguration, msalBroadcastService: MsalBroadcastService, authService: MsalService, location: Location, router: Router);
    /**
     * Parses url string to UrlTree
     * @param url
     */
    parseUrl(url: string): UrlTree;
    /**
     * Builds the absolute url for the destination page
     * @param path Relative path of requested page
     * @returns Full destination url
     */
    getDestinationUrl(path: string): string;
    /**
     * Interactively prompt the user to login
     * @param url Path of the requested page
     */
    private loginInteractively;
    /**
     * Helper which checks for the correct interaction type, prevents page with Guard to be set as redirect, and calls handleRedirectObservable
     * @param state
     */
    private activateHelper;
    includesCode(path: string): boolean;
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree>;
    canMatch(): Observable<boolean | UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MsalGuard>;
}
