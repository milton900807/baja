import { Location } from '@angular/common';
import { IPublicClientApplication, EndSessionRequest, EndSessionPopupRequest, AuthenticationResult, RedirectRequest, SilentRequest, PopupRequest, SsoSilentRequest, Logger } from '@azure/msal-browser';
import { Observable } from 'rxjs';
import { IMsalService } from './IMsalService';
import * as i0 from "@angular/core";
export declare class MsalService implements IMsalService {
    instance: IPublicClientApplication;
    private location;
    private redirectHash;
    private logger;
    constructor(instance: IPublicClientApplication, location: Location);
    initialize(): Observable<void>;
    acquireTokenPopup(request: PopupRequest): Observable<AuthenticationResult>;
    acquireTokenRedirect(request: RedirectRequest): Observable<void>;
    acquireTokenSilent(silentRequest: SilentRequest): Observable<AuthenticationResult>;
    handleRedirectObservable(hash?: string): Observable<AuthenticationResult>;
    loginPopup(request?: PopupRequest): Observable<AuthenticationResult>;
    loginRedirect(request?: RedirectRequest): Observable<void>;
    logout(logoutRequest?: EndSessionRequest): Observable<void>;
    logoutRedirect(logoutRequest?: EndSessionRequest): Observable<void>;
    logoutPopup(logoutRequest?: EndSessionPopupRequest): Observable<void>;
    ssoSilent(request: SsoSilentRequest): Observable<AuthenticationResult>;
    /**
     * Gets logger for msal-angular.
     * If no logger set, returns logger instance created with same options as msal-browser
     */
    getLogger(): Logger;
    setLogger(logger: Logger): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MsalService>;
}
