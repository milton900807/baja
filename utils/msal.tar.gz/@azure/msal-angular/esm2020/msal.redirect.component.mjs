/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * This is a dedicated redirect component to be added to Angular apps to
 * handle redirects when using @azure/msal-angular.
 * Import this component to use redirects in your app.
 */
import { Component } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./msal.service";
export class MsalRedirectComponent {
    constructor(authService) {
        this.authService = authService;
    }
    ngOnInit() {
        this.authService.getLogger().verbose('MsalRedirectComponent activated');
        this.authService.handleRedirectObservable().subscribe();
    }
}
MsalRedirectComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalRedirectComponent, deps: [{ token: i1.MsalService }], target: i0.ɵɵFactoryTarget.Component });
MsalRedirectComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.7", type: MsalRedirectComponent, selector: "app-redirect", ngImport: i0, template: '', isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalRedirectComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-redirect',
                    template: '',
                }]
        }], ctorParameters: function () { return [{ type: i1.MsalService }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNhbC5yZWRpcmVjdC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbXNhbC5yZWRpcmVjdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7OztHQUdHO0FBRUg7Ozs7R0FJRztBQUVILE9BQU8sRUFBRSxTQUFTLEVBQVUsTUFBTSxlQUFlLENBQUM7OztBQU9sRCxNQUFNLE9BQU8scUJBQXFCO0lBQ2hDLFlBQW9CLFdBQXdCO1FBQXhCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO0lBQUcsQ0FBQztJQUVoRCxRQUFRO1FBQ04sSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsV0FBVyxDQUFDLHdCQUF3QixFQUFFLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDMUQsQ0FBQzs7a0hBTlUscUJBQXFCO3NHQUFyQixxQkFBcUIsb0RBRnRCLEVBQUU7MkZBRUQscUJBQXFCO2tCQUpqQyxTQUFTO21CQUFDO29CQUNULFFBQVEsRUFBRSxjQUFjO29CQUN4QixRQUFRLEVBQUUsRUFBRTtpQkFDYiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIFRoaXMgaXMgYSBkZWRpY2F0ZWQgcmVkaXJlY3QgY29tcG9uZW50IHRvIGJlIGFkZGVkIHRvIEFuZ3VsYXIgYXBwcyB0b1xuICogaGFuZGxlIHJlZGlyZWN0cyB3aGVuIHVzaW5nIEBhenVyZS9tc2FsLWFuZ3VsYXIuXG4gKiBJbXBvcnQgdGhpcyBjb21wb25lbnQgdG8gdXNlIHJlZGlyZWN0cyBpbiB5b3VyIGFwcC5cbiAqL1xuXG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTXNhbFNlcnZpY2UgfSBmcm9tICcuL21zYWwuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1yZWRpcmVjdCcsXG4gIHRlbXBsYXRlOiAnJyxcbn0pXG5leHBvcnQgY2xhc3MgTXNhbFJlZGlyZWN0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBhdXRoU2VydmljZTogTXNhbFNlcnZpY2UpIHt9XG5cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5hdXRoU2VydmljZS5nZXRMb2dnZXIoKS52ZXJib3NlKCdNc2FsUmVkaXJlY3RDb21wb25lbnQgYWN0aXZhdGVkJyk7XG4gICAgdGhpcy5hdXRoU2VydmljZS5oYW5kbGVSZWRpcmVjdE9ic2VydmFibGUoKS5zdWJzY3JpYmUoKTtcbiAgfVxufVxuIl19