/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import { Inject, Injectable } from '@angular/core';
import { WrapperSKU, } from '@azure/msal-browser';
import { from } from 'rxjs';
import { name, version } from './packageMetadata';
import { MSAL_INSTANCE } from './constants';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export class MsalService {
    constructor(instance, location) {
        this.instance = instance;
        this.location = location;
        const hash = this.location.path(true).split('#').pop();
        if (hash) {
            this.redirectHash = `#${hash}`;
        }
        this.instance.initializeWrapperLibrary(WrapperSKU.Angular, version);
    }
    initialize() {
        return from(this.instance.initialize());
    }
    acquireTokenPopup(request) {
        return from(this.instance.acquireTokenPopup(request));
    }
    acquireTokenRedirect(request) {
        return from(this.instance.acquireTokenRedirect(request));
    }
    acquireTokenSilent(silentRequest) {
        return from(this.instance.acquireTokenSilent(silentRequest));
    }
    handleRedirectObservable(hash) {
        return from(this.instance
            .initialize()
            .then(() => this.instance.handleRedirectPromise(hash || this.redirectHash)));
    }
    loginPopup(request) {
        return from(this.instance.loginPopup(request));
    }
    loginRedirect(request) {
        return from(this.instance.loginRedirect(request));
    }
    logout(logoutRequest) {
        return from(this.instance.logout(logoutRequest));
    }
    logoutRedirect(logoutRequest) {
        return from(this.instance.logoutRedirect(logoutRequest));
    }
    logoutPopup(logoutRequest) {
        return from(this.instance.logoutPopup(logoutRequest));
    }
    ssoSilent(request) {
        return from(this.instance.ssoSilent(request));
    }
    /**
     * Gets logger for msal-angular.
     * If no logger set, returns logger instance created with same options as msal-browser
     */
    getLogger() {
        if (!this.logger) {
            this.logger = this.instance.getLogger().clone(name, version);
        }
        return this.logger;
    }
    // Create a logger instance for msal-angular with the same options as msal-browser
    setLogger(logger) {
        this.logger = logger.clone(name, version);
        this.instance.setLogger(logger);
    }
}
MsalService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalService, deps: [{ token: MSAL_INSTANCE }, { token: i1.Location }], target: i0.ɵɵFactoryTarget.Injectable });
MsalService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MSAL_INSTANCE]
                }] }, { type: i1.Location }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNhbC5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21zYWwuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7O0dBR0c7QUFFSCxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUVuRCxPQUFPLEVBVUwsVUFBVSxHQUNYLE1BQU0scUJBQXFCLENBQUM7QUFDN0IsT0FBTyxFQUFjLElBQUksRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUV4QyxPQUFPLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxhQUFhLENBQUM7OztBQUc1QyxNQUFNLE9BQU8sV0FBVztJQUl0QixZQUNnQyxRQUFrQyxFQUN4RCxRQUFrQjtRQURJLGFBQVEsR0FBUixRQUFRLENBQTBCO1FBQ3hELGFBQVEsR0FBUixRQUFRLENBQVU7UUFFMUIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3ZELElBQUksSUFBSSxFQUFFO1lBQ1IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFFRCxVQUFVO1FBQ1IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxpQkFBaUIsQ0FBQyxPQUFxQjtRQUNyQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUNELG9CQUFvQixDQUFDLE9BQXdCO1FBQzNDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0Qsa0JBQWtCLENBQ2hCLGFBQTRCO1FBRTVCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBQ0Qsd0JBQXdCLENBQUMsSUFBYTtRQUNwQyxPQUFPLElBQUksQ0FDVCxJQUFJLENBQUMsUUFBUTthQUNWLFVBQVUsRUFBRTthQUNaLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FDVCxJQUFJLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQy9ELENBQ0osQ0FBQztJQUNKLENBQUM7SUFDRCxVQUFVLENBQUMsT0FBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsYUFBYSxDQUFDLE9BQXlCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELE1BQU0sQ0FBQyxhQUFpQztRQUN0QyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDRCxjQUFjLENBQUMsYUFBaUM7UUFDOUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0QsV0FBVyxDQUFDLGFBQXNDO1FBQ2hELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUNELFNBQVMsQ0FBQyxPQUF5QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDRDs7O09BR0c7SUFDSCxTQUFTO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDOUQ7UUFDRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7SUFDckIsQ0FBQztJQUNELGtGQUFrRjtJQUNsRixTQUFTLENBQUMsTUFBYztRQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2xDLENBQUM7O3dHQXRFVSxXQUFXLGtCQUtaLGFBQWE7NEdBTFosV0FBVzsyRkFBWCxXQUFXO2tCQUR2QixVQUFVOzswQkFNTixNQUFNOzJCQUFDLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQge1xuICBJUHVibGljQ2xpZW50QXBwbGljYXRpb24sXG4gIEVuZFNlc3Npb25SZXF1ZXN0LFxuICBFbmRTZXNzaW9uUG9wdXBSZXF1ZXN0LFxuICBBdXRoZW50aWNhdGlvblJlc3VsdCxcbiAgUmVkaXJlY3RSZXF1ZXN0LFxuICBTaWxlbnRSZXF1ZXN0LFxuICBQb3B1cFJlcXVlc3QsXG4gIFNzb1NpbGVudFJlcXVlc3QsXG4gIExvZ2dlcixcbiAgV3JhcHBlclNLVSxcbn0gZnJvbSAnQGF6dXJlL21zYWwtYnJvd3Nlcic7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBmcm9tIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBJTXNhbFNlcnZpY2UgfSBmcm9tICcuL0lNc2FsU2VydmljZSc7XG5pbXBvcnQgeyBuYW1lLCB2ZXJzaW9uIH0gZnJvbSAnLi9wYWNrYWdlTWV0YWRhdGEnO1xuaW1wb3J0IHsgTVNBTF9JTlNUQU5DRSB9IGZyb20gJy4vY29uc3RhbnRzJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIE1zYWxTZXJ2aWNlIGltcGxlbWVudHMgSU1zYWxTZXJ2aWNlIHtcbiAgcHJpdmF0ZSByZWRpcmVjdEhhc2g6IHN0cmluZztcbiAgcHJpdmF0ZSBsb2dnZXI6IExvZ2dlcjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBASW5qZWN0KE1TQUxfSU5TVEFOQ0UpIHB1YmxpYyBpbnN0YW5jZTogSVB1YmxpY0NsaWVudEFwcGxpY2F0aW9uLFxuICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uXG4gICkge1xuICAgIGNvbnN0IGhhc2ggPSB0aGlzLmxvY2F0aW9uLnBhdGgodHJ1ZSkuc3BsaXQoJyMnKS5wb3AoKTtcbiAgICBpZiAoaGFzaCkge1xuICAgICAgdGhpcy5yZWRpcmVjdEhhc2ggPSBgIyR7aGFzaH1gO1xuICAgIH1cbiAgICB0aGlzLmluc3RhbmNlLmluaXRpYWxpemVXcmFwcGVyTGlicmFyeShXcmFwcGVyU0tVLkFuZ3VsYXIsIHZlcnNpb24pO1xuICB9XG5cbiAgaW5pdGlhbGl6ZSgpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICByZXR1cm4gZnJvbSh0aGlzLmluc3RhbmNlLmluaXRpYWxpemUoKSk7XG4gIH1cbiAgYWNxdWlyZVRva2VuUG9wdXAocmVxdWVzdDogUG9wdXBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxBdXRoZW50aWNhdGlvblJlc3VsdD4ge1xuICAgIHJldHVybiBmcm9tKHRoaXMuaW5zdGFuY2UuYWNxdWlyZVRva2VuUG9wdXAocmVxdWVzdCkpO1xuICB9XG4gIGFjcXVpcmVUb2tlblJlZGlyZWN0KHJlcXVlc3Q6IFJlZGlyZWN0UmVxdWVzdCk6IE9ic2VydmFibGU8dm9pZD4ge1xuICAgIHJldHVybiBmcm9tKHRoaXMuaW5zdGFuY2UuYWNxdWlyZVRva2VuUmVkaXJlY3QocmVxdWVzdCkpO1xuICB9XG4gIGFjcXVpcmVUb2tlblNpbGVudChcbiAgICBzaWxlbnRSZXF1ZXN0OiBTaWxlbnRSZXF1ZXN0XG4gICk6IE9ic2VydmFibGU8QXV0aGVudGljYXRpb25SZXN1bHQ+IHtcbiAgICByZXR1cm4gZnJvbSh0aGlzLmluc3RhbmNlLmFjcXVpcmVUb2tlblNpbGVudChzaWxlbnRSZXF1ZXN0KSk7XG4gIH1cbiAgaGFuZGxlUmVkaXJlY3RPYnNlcnZhYmxlKGhhc2g/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEF1dGhlbnRpY2F0aW9uUmVzdWx0PiB7XG4gICAgcmV0dXJuIGZyb20oXG4gICAgICB0aGlzLmluc3RhbmNlXG4gICAgICAgIC5pbml0aWFsaXplKClcbiAgICAgICAgLnRoZW4oKCkgPT5cbiAgICAgICAgICB0aGlzLmluc3RhbmNlLmhhbmRsZVJlZGlyZWN0UHJvbWlzZShoYXNoIHx8IHRoaXMucmVkaXJlY3RIYXNoKVxuICAgICAgICApXG4gICAgKTtcbiAgfVxuICBsb2dpblBvcHVwKHJlcXVlc3Q/OiBQb3B1cFJlcXVlc3QpOiBPYnNlcnZhYmxlPEF1dGhlbnRpY2F0aW9uUmVzdWx0PiB7XG4gICAgcmV0dXJuIGZyb20odGhpcy5pbnN0YW5jZS5sb2dpblBvcHVwKHJlcXVlc3QpKTtcbiAgfVxuICBsb2dpblJlZGlyZWN0KHJlcXVlc3Q/OiBSZWRpcmVjdFJlcXVlc3QpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICByZXR1cm4gZnJvbSh0aGlzLmluc3RhbmNlLmxvZ2luUmVkaXJlY3QocmVxdWVzdCkpO1xuICB9XG4gIGxvZ291dChsb2dvdXRSZXF1ZXN0PzogRW5kU2Vzc2lvblJlcXVlc3QpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICByZXR1cm4gZnJvbSh0aGlzLmluc3RhbmNlLmxvZ291dChsb2dvdXRSZXF1ZXN0KSk7XG4gIH1cbiAgbG9nb3V0UmVkaXJlY3QobG9nb3V0UmVxdWVzdD86IEVuZFNlc3Npb25SZXF1ZXN0KTogT2JzZXJ2YWJsZTx2b2lkPiB7XG4gICAgcmV0dXJuIGZyb20odGhpcy5pbnN0YW5jZS5sb2dvdXRSZWRpcmVjdChsb2dvdXRSZXF1ZXN0KSk7XG4gIH1cbiAgbG9nb3V0UG9wdXAobG9nb3V0UmVxdWVzdD86IEVuZFNlc3Npb25Qb3B1cFJlcXVlc3QpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICByZXR1cm4gZnJvbSh0aGlzLmluc3RhbmNlLmxvZ291dFBvcHVwKGxvZ291dFJlcXVlc3QpKTtcbiAgfVxuICBzc29TaWxlbnQocmVxdWVzdDogU3NvU2lsZW50UmVxdWVzdCk6IE9ic2VydmFibGU8QXV0aGVudGljYXRpb25SZXN1bHQ+IHtcbiAgICByZXR1cm4gZnJvbSh0aGlzLmluc3RhbmNlLnNzb1NpbGVudChyZXF1ZXN0KSk7XG4gIH1cbiAgLyoqXG4gICAqIEdldHMgbG9nZ2VyIGZvciBtc2FsLWFuZ3VsYXIuXG4gICAqIElmIG5vIGxvZ2dlciBzZXQsIHJldHVybnMgbG9nZ2VyIGluc3RhbmNlIGNyZWF0ZWQgd2l0aCBzYW1lIG9wdGlvbnMgYXMgbXNhbC1icm93c2VyXG4gICAqL1xuICBnZXRMb2dnZXIoKTogTG9nZ2VyIHtcbiAgICBpZiAoIXRoaXMubG9nZ2VyKSB7XG4gICAgICB0aGlzLmxvZ2dlciA9IHRoaXMuaW5zdGFuY2UuZ2V0TG9nZ2VyKCkuY2xvbmUobmFtZSwgdmVyc2lvbik7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmxvZ2dlcjtcbiAgfVxuICAvLyBDcmVhdGUgYSBsb2dnZXIgaW5zdGFuY2UgZm9yIG1zYWwtYW5ndWxhciB3aXRoIHRoZSBzYW1lIG9wdGlvbnMgYXMgbXNhbC1icm93c2VyXG4gIHNldExvZ2dlcihsb2dnZXI6IExvZ2dlcik6IHZvaWQge1xuICAgIHRoaXMubG9nZ2VyID0gbG9nZ2VyLmNsb25lKG5hbWUsIHZlcnNpb24pO1xuICAgIHRoaXMuaW5zdGFuY2Uuc2V0TG9nZ2VyKGxvZ2dlcik7XG4gIH1cbn1cbiJdfQ==