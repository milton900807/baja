export declare type MsalBroadcastConfiguration = {
    eventsToReplay: number;
};
