/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import { Inject, Injectable, Optional } from '@angular/core';
import { EventMessageUtils, InteractionStatus, } from '@azure/msal-browser';
import { BehaviorSubject, ReplaySubject, Subject } from 'rxjs';
import { MSAL_BROADCAST_CONFIG, MSAL_INSTANCE } from './constants';
import * as i0 from "@angular/core";
import * as i1 from "./msal.service";
export class MsalBroadcastService {
    constructor(msalInstance, authService, msalBroadcastConfig) {
        this.msalInstance = msalInstance;
        this.authService = authService;
        this.msalBroadcastConfig = msalBroadcastConfig;
        // Make _msalSubject a ReplaySubject if configured to replay past events
        if (this.msalBroadcastConfig &&
            this.msalBroadcastConfig.eventsToReplay > 0) {
            this.authService
                .getLogger()
                .verbose(`BroadcastService - eventsToReplay set on BroadcastConfig, replaying the last ${this.msalBroadcastConfig.eventsToReplay} events`);
            this._msalSubject = new ReplaySubject(this.msalBroadcastConfig.eventsToReplay);
        }
        else {
            // Defaults to _msalSubject being a Subject
            this._msalSubject = new Subject();
        }
        this.msalSubject$ = this._msalSubject.asObservable();
        // InProgress as BehaviorSubject so most recent inProgress state will be available upon subscription
        this._inProgress = new BehaviorSubject(InteractionStatus.Startup);
        this.inProgress$ = this._inProgress.asObservable();
        this.msalInstance.addEventCallback((message) => {
            this._msalSubject.next(message);
            const status = EventMessageUtils.getInteractionStatusFromEvent(message, this._inProgress.value);
            if (status !== null) {
                this.authService
                    .getLogger()
                    .verbose(`BroadcastService - ${message.eventType} results in setting inProgress from ${this._inProgress.value} to ${status}`);
                this._inProgress.next(status);
            }
        });
    }
}
MsalBroadcastService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalBroadcastService, deps: [{ token: MSAL_INSTANCE }, { token: i1.MsalService }, { token: MSAL_BROADCAST_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
MsalBroadcastService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalBroadcastService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalBroadcastService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MSAL_INSTANCE]
                }] }, { type: i1.MsalService }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [MSAL_BROADCAST_CONFIG]
                }] }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNhbC5icm9hZGNhc3Quc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tc2FsLmJyb2FkY2FzdC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUVILE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM3RCxPQUFPLEVBRUwsaUJBQWlCLEVBRWpCLGlCQUFpQixHQUNsQixNQUFNLHFCQUFxQixDQUFDO0FBQzdCLE9BQU8sRUFBRSxlQUFlLEVBQWMsYUFBYSxFQUFFLE9BQU8sRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUczRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsYUFBYSxFQUFFLE1BQU0sYUFBYSxDQUFDOzs7QUFHbkUsTUFBTSxPQUFPLG9CQUFvQjtJQU0vQixZQUNpQyxZQUFzQyxFQUM3RCxXQUF3QixFQUd4QixtQkFBZ0Q7UUFKekIsaUJBQVksR0FBWixZQUFZLENBQTBCO1FBQzdELGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBR3hCLHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBNkI7UUFFeEQsd0VBQXdFO1FBQ3hFLElBQ0UsSUFBSSxDQUFDLG1CQUFtQjtZQUN4QixJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxHQUFHLENBQUMsRUFDM0M7WUFDQSxJQUFJLENBQUMsV0FBVztpQkFDYixTQUFTLEVBQUU7aUJBQ1gsT0FBTyxDQUNOLGdGQUFnRixJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxTQUFTLENBQ2pJLENBQUM7WUFDSixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksYUFBYSxDQUNuQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUN4QyxDQUFDO1NBQ0g7YUFBTTtZQUNMLDJDQUEyQztZQUMzQyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksT0FBTyxFQUFnQixDQUFDO1NBQ2pEO1FBRUQsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBRXJELG9HQUFvRztRQUNwRyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksZUFBZSxDQUNwQyxpQkFBaUIsQ0FBQyxPQUFPLENBQzFCLENBQUM7UUFDRixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFbkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQXFCLEVBQUUsRUFBRTtZQUMzRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoQyxNQUFNLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQyw2QkFBNkIsQ0FDNUQsT0FBTyxFQUNQLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUN2QixDQUFDO1lBQ0YsSUFBSSxNQUFNLEtBQUssSUFBSSxFQUFFO2dCQUNuQixJQUFJLENBQUMsV0FBVztxQkFDYixTQUFTLEVBQUU7cUJBQ1gsT0FBTyxDQUNOLHNCQUFzQixPQUFPLENBQUMsU0FBUyx1Q0FBdUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLE9BQU8sTUFBTSxFQUFFLENBQ3BILENBQUM7Z0JBQ0osSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDL0I7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7O2lIQXREVSxvQkFBb0Isa0JBT3JCLGFBQWEsd0NBR2IscUJBQXFCO3FIQVZwQixvQkFBb0I7MkZBQXBCLG9CQUFvQjtrQkFEaEMsVUFBVTs7MEJBUU4sTUFBTTsyQkFBQyxhQUFhOzswQkFFcEIsUUFBUTs7MEJBQ1IsTUFBTTsyQkFBQyxxQkFBcUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlLCBPcHRpb25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgRXZlbnRNZXNzYWdlLFxuICBFdmVudE1lc3NhZ2VVdGlscyxcbiAgSVB1YmxpY0NsaWVudEFwcGxpY2F0aW9uLFxuICBJbnRlcmFjdGlvblN0YXR1cyxcbn0gZnJvbSAnQGF6dXJlL21zYWwtYnJvd3Nlcic7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIE9ic2VydmFibGUsIFJlcGxheVN1YmplY3QsIFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE1zYWxTZXJ2aWNlIH0gZnJvbSAnLi9tc2FsLnNlcnZpY2UnO1xuaW1wb3J0IHsgTXNhbEJyb2FkY2FzdENvbmZpZ3VyYXRpb24gfSBmcm9tICcuL21zYWwuYnJvYWRjYXN0LmNvbmZpZyc7XG5pbXBvcnQgeyBNU0FMX0JST0FEQ0FTVF9DT05GSUcsIE1TQUxfSU5TVEFOQ0UgfSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBNc2FsQnJvYWRjYXN0U2VydmljZSB7XG4gIHByaXZhdGUgX21zYWxTdWJqZWN0OiBTdWJqZWN0PEV2ZW50TWVzc2FnZT47XG4gIHB1YmxpYyBtc2FsU3ViamVjdCQ6IE9ic2VydmFibGU8RXZlbnRNZXNzYWdlPjtcbiAgcHJpdmF0ZSBfaW5Qcm9ncmVzczogQmVoYXZpb3JTdWJqZWN0PEludGVyYWN0aW9uU3RhdHVzPjtcbiAgcHVibGljIGluUHJvZ3Jlc3MkOiBPYnNlcnZhYmxlPEludGVyYWN0aW9uU3RhdHVzPjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBASW5qZWN0KE1TQUxfSU5TVEFOQ0UpIHByaXZhdGUgbXNhbEluc3RhbmNlOiBJUHVibGljQ2xpZW50QXBwbGljYXRpb24sXG4gICAgcHJpdmF0ZSBhdXRoU2VydmljZTogTXNhbFNlcnZpY2UsXG4gICAgQE9wdGlvbmFsKClcbiAgICBASW5qZWN0KE1TQUxfQlJPQURDQVNUX0NPTkZJRylcbiAgICBwcml2YXRlIG1zYWxCcm9hZGNhc3RDb25maWc/OiBNc2FsQnJvYWRjYXN0Q29uZmlndXJhdGlvblxuICApIHtcbiAgICAvLyBNYWtlIF9tc2FsU3ViamVjdCBhIFJlcGxheVN1YmplY3QgaWYgY29uZmlndXJlZCB0byByZXBsYXkgcGFzdCBldmVudHNcbiAgICBpZiAoXG4gICAgICB0aGlzLm1zYWxCcm9hZGNhc3RDb25maWcgJiZcbiAgICAgIHRoaXMubXNhbEJyb2FkY2FzdENvbmZpZy5ldmVudHNUb1JlcGxheSA+IDBcbiAgICApIHtcbiAgICAgIHRoaXMuYXV0aFNlcnZpY2VcbiAgICAgICAgLmdldExvZ2dlcigpXG4gICAgICAgIC52ZXJib3NlKFxuICAgICAgICAgIGBCcm9hZGNhc3RTZXJ2aWNlIC0gZXZlbnRzVG9SZXBsYXkgc2V0IG9uIEJyb2FkY2FzdENvbmZpZywgcmVwbGF5aW5nIHRoZSBsYXN0ICR7dGhpcy5tc2FsQnJvYWRjYXN0Q29uZmlnLmV2ZW50c1RvUmVwbGF5fSBldmVudHNgXG4gICAgICAgICk7XG4gICAgICB0aGlzLl9tc2FsU3ViamVjdCA9IG5ldyBSZXBsYXlTdWJqZWN0PEV2ZW50TWVzc2FnZT4oXG4gICAgICAgIHRoaXMubXNhbEJyb2FkY2FzdENvbmZpZy5ldmVudHNUb1JlcGxheVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gRGVmYXVsdHMgdG8gX21zYWxTdWJqZWN0IGJlaW5nIGEgU3ViamVjdFxuICAgICAgdGhpcy5fbXNhbFN1YmplY3QgPSBuZXcgU3ViamVjdDxFdmVudE1lc3NhZ2U+KCk7XG4gICAgfVxuXG4gICAgdGhpcy5tc2FsU3ViamVjdCQgPSB0aGlzLl9tc2FsU3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICAgIC8vIEluUHJvZ3Jlc3MgYXMgQmVoYXZpb3JTdWJqZWN0IHNvIG1vc3QgcmVjZW50IGluUHJvZ3Jlc3Mgc3RhdGUgd2lsbCBiZSBhdmFpbGFibGUgdXBvbiBzdWJzY3JpcHRpb25cbiAgICB0aGlzLl9pblByb2dyZXNzID0gbmV3IEJlaGF2aW9yU3ViamVjdDxJbnRlcmFjdGlvblN0YXR1cz4oXG4gICAgICBJbnRlcmFjdGlvblN0YXR1cy5TdGFydHVwXG4gICAgKTtcbiAgICB0aGlzLmluUHJvZ3Jlc3MkID0gdGhpcy5faW5Qcm9ncmVzcy5hc09ic2VydmFibGUoKTtcblxuICAgIHRoaXMubXNhbEluc3RhbmNlLmFkZEV2ZW50Q2FsbGJhY2soKG1lc3NhZ2U6IEV2ZW50TWVzc2FnZSkgPT4ge1xuICAgICAgdGhpcy5fbXNhbFN1YmplY3QubmV4dChtZXNzYWdlKTtcbiAgICAgIGNvbnN0IHN0YXR1cyA9IEV2ZW50TWVzc2FnZVV0aWxzLmdldEludGVyYWN0aW9uU3RhdHVzRnJvbUV2ZW50KFxuICAgICAgICBtZXNzYWdlLFxuICAgICAgICB0aGlzLl9pblByb2dyZXNzLnZhbHVlXG4gICAgICApO1xuICAgICAgaWYgKHN0YXR1cyAhPT0gbnVsbCkge1xuICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAgICAgLmdldExvZ2dlcigpXG4gICAgICAgICAgLnZlcmJvc2UoXG4gICAgICAgICAgICBgQnJvYWRjYXN0U2VydmljZSAtICR7bWVzc2FnZS5ldmVudFR5cGV9IHJlc3VsdHMgaW4gc2V0dGluZyBpblByb2dyZXNzIGZyb20gJHt0aGlzLl9pblByb2dyZXNzLnZhbHVlfSB0byAke3N0YXR1c31gXG4gICAgICAgICAgKTtcbiAgICAgICAgdGhpcy5faW5Qcm9ncmVzcy5uZXh0KHN0YXR1cyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==