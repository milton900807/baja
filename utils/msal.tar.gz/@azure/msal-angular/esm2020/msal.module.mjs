/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MsalBroadcastService } from './msal.broadcast.service';
import { MsalGuard } from './msal.guard';
import { MsalRedirectComponent } from './msal.redirect.component';
import { MsalService } from './msal.service';
import { MSAL_INSTANCE, MSAL_GUARD_CONFIG, MSAL_INTERCEPTOR_CONFIG, } from './constants';
import * as i0 from "@angular/core";
export class MsalModule {
    static forRoot(msalInstance, guardConfig, interceptorConfig) {
        return {
            ngModule: MsalModule,
            providers: [
                {
                    provide: MSAL_INSTANCE,
                    useValue: msalInstance,
                },
                {
                    provide: MSAL_GUARD_CONFIG,
                    useValue: guardConfig,
                },
                {
                    provide: MSAL_INTERCEPTOR_CONFIG,
                    useValue: interceptorConfig,
                },
                MsalService,
            ],
        };
    }
}
MsalModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
MsalModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, declarations: [MsalRedirectComponent], imports: [CommonModule] });
MsalModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, providers: [MsalGuard, MsalBroadcastService], imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MsalRedirectComponent],
                    imports: [CommonModule],
                    providers: [MsalGuard, MsalBroadcastService],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNhbC5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbXNhbC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7OztHQUdHO0FBRUgsT0FBTyxFQUF1QixRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDOUQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRS9DLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFHekMsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDbEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFDTCxhQUFhLEVBQ2IsaUJBQWlCLEVBQ2pCLHVCQUF1QixHQUN4QixNQUFNLGFBQWEsQ0FBQzs7QUFPckIsTUFBTSxPQUFPLFVBQVU7SUFDckIsTUFBTSxDQUFDLE9BQU8sQ0FDWixZQUFzQyxFQUN0QyxXQUFtQyxFQUNuQyxpQkFBK0M7UUFFL0MsT0FBTztZQUNMLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLFNBQVMsRUFBRTtnQkFDVDtvQkFDRSxPQUFPLEVBQUUsYUFBYTtvQkFDdEIsUUFBUSxFQUFFLFlBQVk7aUJBQ3ZCO2dCQUNEO29CQUNFLE9BQU8sRUFBRSxpQkFBaUI7b0JBQzFCLFFBQVEsRUFBRSxXQUFXO2lCQUN0QjtnQkFDRDtvQkFDRSxPQUFPLEVBQUUsdUJBQXVCO29CQUNoQyxRQUFRLEVBQUUsaUJBQWlCO2lCQUM1QjtnQkFDRCxXQUFXO2FBQ1o7U0FDRixDQUFDO0lBQ0osQ0FBQzs7dUdBeEJVLFVBQVU7d0dBQVYsVUFBVSxpQkFKTixxQkFBcUIsYUFDMUIsWUFBWTt3R0FHWCxVQUFVLGFBRlYsQ0FBQyxTQUFTLEVBQUUsb0JBQW9CLENBQUMsWUFEbEMsWUFBWTsyRkFHWCxVQUFVO2tCQUx0QixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRSxDQUFDLHFCQUFxQixDQUFDO29CQUNyQyxPQUFPLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3ZCLFNBQVMsRUFBRSxDQUFDLFNBQVMsRUFBRSxvQkFBb0IsQ0FBQztpQkFDN0MiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgTW9kdWxlV2l0aFByb3ZpZGVycywgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBJUHVibGljQ2xpZW50QXBwbGljYXRpb24gfSBmcm9tICdAYXp1cmUvbXNhbC1icm93c2VyJztcbmltcG9ydCB7IE1zYWxCcm9hZGNhc3RTZXJ2aWNlIH0gZnJvbSAnLi9tc2FsLmJyb2FkY2FzdC5zZXJ2aWNlJztcbmltcG9ydCB7IE1zYWxHdWFyZCB9IGZyb20gJy4vbXNhbC5ndWFyZCc7XG5pbXBvcnQgeyBNc2FsR3VhcmRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9tc2FsLmd1YXJkLmNvbmZpZyc7XG5pbXBvcnQgeyBNc2FsSW50ZXJjZXB0b3JDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9tc2FsLmludGVyY2VwdG9yLmNvbmZpZyc7XG5pbXBvcnQgeyBNc2FsUmVkaXJlY3RDb21wb25lbnQgfSBmcm9tICcuL21zYWwucmVkaXJlY3QuY29tcG9uZW50JztcbmltcG9ydCB7IE1zYWxTZXJ2aWNlIH0gZnJvbSAnLi9tc2FsLnNlcnZpY2UnO1xuaW1wb3J0IHtcbiAgTVNBTF9JTlNUQU5DRSxcbiAgTVNBTF9HVUFSRF9DT05GSUcsXG4gIE1TQUxfSU5URVJDRVBUT1JfQ09ORklHLFxufSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW01zYWxSZWRpcmVjdENvbXBvbmVudF0sXG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGVdLFxuICBwcm92aWRlcnM6IFtNc2FsR3VhcmQsIE1zYWxCcm9hZGNhc3RTZXJ2aWNlXSxcbn0pXG5leHBvcnQgY2xhc3MgTXNhbE1vZHVsZSB7XG4gIHN0YXRpYyBmb3JSb290KFxuICAgIG1zYWxJbnN0YW5jZTogSVB1YmxpY0NsaWVudEFwcGxpY2F0aW9uLFxuICAgIGd1YXJkQ29uZmlnOiBNc2FsR3VhcmRDb25maWd1cmF0aW9uLFxuICAgIGludGVyY2VwdG9yQ29uZmlnOiBNc2FsSW50ZXJjZXB0b3JDb25maWd1cmF0aW9uXG4gICk6IE1vZHVsZVdpdGhQcm92aWRlcnM8TXNhbE1vZHVsZT4ge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogTXNhbE1vZHVsZSxcbiAgICAgIHByb3ZpZGVyczogW1xuICAgICAgICB7XG4gICAgICAgICAgcHJvdmlkZTogTVNBTF9JTlNUQU5DRSxcbiAgICAgICAgICB1c2VWYWx1ZTogbXNhbEluc3RhbmNlLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgcHJvdmlkZTogTVNBTF9HVUFSRF9DT05GSUcsXG4gICAgICAgICAgdXNlVmFsdWU6IGd1YXJkQ29uZmlnLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgcHJvdmlkZTogTVNBTF9JTlRFUkNFUFRPUl9DT05GSUcsXG4gICAgICAgICAgdXNlVmFsdWU6IGludGVyY2VwdG9yQ29uZmlnLFxuICAgICAgICB9LFxuICAgICAgICBNc2FsU2VydmljZSxcbiAgICAgIF0sXG4gICAgfTtcbiAgfVxufVxuIl19