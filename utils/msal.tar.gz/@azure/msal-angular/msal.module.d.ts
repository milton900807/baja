import { ModuleWithProviders } from '@angular/core';
import { IPublicClientApplication } from '@azure/msal-browser';
import { MsalGuardConfiguration } from './msal.guard.config';
import { MsalInterceptorConfiguration } from './msal.interceptor.config';
import * as i0 from "@angular/core";
import * as i1 from "./msal.redirect.component";
import * as i2 from "@angular/common";
export declare class MsalModule {
    static forRoot(msalInstance: IPublicClientApplication, guardConfig: MsalGuardConfiguration, interceptorConfig: MsalInterceptorConfiguration): ModuleWithProviders<MsalModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MsalModule, [typeof i1.MsalRedirectComponent], [typeof i2.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MsalModule>;
}
