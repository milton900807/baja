import { EventMessage, IPublicClientApplication, InteractionStatus } from '@azure/msal-browser';
import { Observable } from 'rxjs';
import { MsalService } from './msal.service';
import { MsalBroadcastConfiguration } from './msal.broadcast.config';
import * as i0 from "@angular/core";
export declare class MsalBroadcastService {
    private msalInstance;
    private authService;
    private msalBroadcastConfig?;
    private _msalSubject;
    msalSubject$: Observable<EventMessage>;
    private _inProgress;
    inProgress$: Observable<InteractionStatus>;
    constructor(msalInstance: IPublicClientApplication, authService: MsalService, msalBroadcastConfig?: MsalBroadcastConfiguration);
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalBroadcastService, [null, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MsalBroadcastService>;
}
