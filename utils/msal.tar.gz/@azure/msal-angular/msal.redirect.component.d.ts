/**
 * This is a dedicated redirect component to be added to Angular apps to
 * handle redirects when using @azure/msal-angular.
 * Import this component to use redirects in your app.
 */
import { OnInit } from '@angular/core';
import { MsalService } from './msal.service';
import * as i0 from "@angular/core";
export declare class MsalRedirectComponent implements OnInit {
    private authService;
    constructor(authService: MsalService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalRedirectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MsalRedirectComponent, "app-redirect", never, {}, {}, never, never, false, never>;
}
