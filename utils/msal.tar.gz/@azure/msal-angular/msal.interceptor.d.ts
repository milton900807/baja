import { Location } from '@angular/common';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MsalService } from './msal.service';
import { MsalInterceptorConfiguration } from './msal.interceptor.config';
import { MsalBroadcastService } from './msal.broadcast.service';
import * as i0 from "@angular/core";
export declare class MsalInterceptor implements HttpInterceptor {
    private msalInterceptorConfig;
    private authService;
    private location;
    private msalBroadcastService;
    private _document?;
    constructor(msalInterceptorConfig: MsalInterceptorConfiguration, authService: MsalService, location: Location, msalBroadcastService: MsalBroadcastService, document?: any);
    intercept(req: HttpRequest<any>, // eslint-disable-line @typescript-eslint/no-explicit-any
    next: HttpHandler): Observable<HttpEvent<any>>;
    /**
     * Try to acquire token silently. Invoke interaction if acquireTokenSilent rejected with error or resolved with null access token
     * @param authRequest Request
     * @param scopes Array of scopes for the request
     * @param account Account
     * @returns Authentication result
     */
    private acquireToken;
    /**
     * Invoke interaction for the given set of scopes
     * @param authRequest Request
     * @param scopes Array of scopes for the request
     * @returns Result from the interactive request
     */
    private acquireTokenInteractively;
    /**
     * Looks up the scopes for the given endpoint from the protectedResourceMap
     * @param endpoint Url of the request
     * @param httpMethod Http method of the request
     * @returns Array of scopes, or null if not found
     *
     */
    private getScopesForEndpoint;
    /**
     * Finds resource endpoints that match request endpoint
     * @param protectedResourcesEndpoints
     * @param endpoint
     * @returns
     */
    private matchResourcesToEndpoint;
    /**
     * Transforms relative urls to absolute urls
     * @param url
     * @returns
     */
    private getAbsoluteUrl;
    /**
     * Finds scopes from first matching endpoint with HTTP method that matches request
     * @param protectedResourceMap Protected resource map
     * @param endpointArray Array of resources that match request endpoint
     * @param httpMethod Http method of the request
     * @returns
     */
    private matchScopesToEndpoint;
    static ɵfac: i0.ɵɵFactoryDeclaration<MsalInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MsalInterceptor>;
}
