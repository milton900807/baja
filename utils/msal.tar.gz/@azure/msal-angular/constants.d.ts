import { InjectionToken } from '@angular/core';
export declare const MSAL_INSTANCE: InjectionToken<string>;
export declare const MSAL_GUARD_CONFIG: InjectionToken<string>;
export declare const MSAL_INTERCEPTOR_CONFIG: InjectionToken<string>;
export declare const MSAL_BROADCAST_CONFIG: InjectionToken<string>;
