/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import { Injectable, Inject } from '@angular/core';
import { InteractionType, BrowserConfigurationAuthError, BrowserUtils, UrlString, } from '@azure/msal-browser';
import { of } from 'rxjs';
import { concatMap, catchError, map } from 'rxjs/operators';
import { MSAL_GUARD_CONFIG } from './constants';
import * as i0 from "@angular/core";
import * as i1 from "./msal.broadcast.service";
import * as i2 from "./msal.service";
import * as i3 from "@angular/common";
import * as i4 from "@angular/router";
export class MsalGuard {
    constructor(msalGuardConfig, msalBroadcastService, authService, location, router) {
        this.msalGuardConfig = msalGuardConfig;
        this.msalBroadcastService = msalBroadcastService;
        this.authService = authService;
        this.location = location;
        this.router = router;
        // Subscribing so events in MsalGuard will set inProgress$ observable
        this.msalBroadcastService.inProgress$.subscribe();
    }
    /**
     * Parses url string to UrlTree
     * @param url
     */
    parseUrl(url) {
        return this.router.parseUrl(url);
    }
    /**
     * Builds the absolute url for the destination page
     * @param path Relative path of requested page
     * @returns Full destination url
     */
    getDestinationUrl(path) {
        this.authService.getLogger().verbose('Guard - getting destination url');
        // Absolute base url for the application (default to origin if base element not present)
        const baseElements = document.getElementsByTagName('base');
        const baseUrl = this.location.normalize(baseElements.length ? baseElements[0].href : window.location.origin);
        // Path of page (including hash, if using hash routing)
        const pathUrl = this.location.prepareExternalUrl(path);
        // Hash location strategy
        if (pathUrl.startsWith('#')) {
            this.authService
                .getLogger()
                .verbose('Guard - destination by hash routing');
            return `${baseUrl}/${pathUrl}`;
        }
        /*
         * If using path location strategy, pathUrl will include the relative portion of the base path (e.g. /base/page).
         * Since baseUrl also includes /base, can just concatentate baseUrl + path
         */
        return `${baseUrl}${path}`;
    }
    /**
     * Interactively prompt the user to login
     * @param url Path of the requested page
     */
    loginInteractively(state) {
        const authRequest = typeof this.msalGuardConfig.authRequest === 'function'
            ? this.msalGuardConfig.authRequest(this.authService, state)
            : { ...this.msalGuardConfig.authRequest };
        if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
            this.authService.getLogger().verbose('Guard - logging in by popup');
            return this.authService.loginPopup(authRequest).pipe(map((response) => {
                this.authService
                    .getLogger()
                    .verbose('Guard - login by popup successful, can activate, setting active account');
                this.authService.instance.setActiveAccount(response.account);
                return true;
            }));
        }
        this.authService.getLogger().verbose('Guard - logging in by redirect');
        const redirectStartPage = this.getDestinationUrl(state.url);
        return this.authService
            .loginRedirect({
            redirectStartPage,
            ...authRequest,
        })
            .pipe(map(() => false));
    }
    /**
     * Helper which checks for the correct interaction type, prevents page with Guard to be set as redirect, and calls handleRedirectObservable
     * @param state
     */
    activateHelper(state) {
        if (this.msalGuardConfig.interactionType !== InteractionType.Popup &&
            this.msalGuardConfig.interactionType !== InteractionType.Redirect) {
            throw new BrowserConfigurationAuthError('invalid_interaction_type', 'Invalid interaction type provided to MSAL Guard. InteractionType.Popup or InteractionType.Redirect must be provided in the MsalGuardConfiguration');
        }
        this.authService.getLogger().verbose('MSAL Guard activated');
        /*
         * If a page with MSAL Guard is set as the redirect for acquireTokenSilent,
         * short-circuit to prevent redirecting or popups.
         */
        if (typeof window !== 'undefined') {
            if (UrlString.hashContainsKnownProperties(window.location.hash) &&
                BrowserUtils.isInIframe() &&
                !this.authService.instance.getConfiguration().system
                    .allowRedirectInIframe) {
                this.authService
                    .getLogger()
                    .warning('Guard - redirectUri set to page with MSAL Guard. It is recommended to not set redirectUri to a page that requires authentication.');
                return of(false);
            }
        }
        else {
            this.authService
                .getLogger()
                .info('Guard - window is undefined, MSAL does not support server-side token acquisition');
            return of(true);
        }
        /**
         * If a loginFailedRoute is set in the config, set this as the loginFailedRoute
         */
        if (this.msalGuardConfig.loginFailedRoute) {
            this.loginFailedRoute = this.parseUrl(this.msalGuardConfig.loginFailedRoute);
        }
        // Capture current path before it gets changed by handleRedirectObservable
        const currentPath = this.location.path(true);
        return this.authService.initialize().pipe(concatMap(() => {
            return this.authService.handleRedirectObservable();
        }), concatMap(() => {
            if (!this.authService.instance.getAllAccounts().length) {
                if (state) {
                    this.authService
                        .getLogger()
                        .verbose('Guard - no accounts retrieved, log in required to activate');
                    return this.loginInteractively(state);
                }
                this.authService
                    .getLogger()
                    .verbose('Guard - no accounts retrieved, no state, cannot load');
                return of(false);
            }
            this.authService
                .getLogger()
                .verbose('Guard - at least 1 account exists, can activate or load');
            // Prevent navigating the app to /#code= or /code=
            if (state) {
                /*
                 * Path routing:
                 * state.url: /#code=...
                 * state.root.fragment: code=...
                 */
                /*
                 * Hash routing:
                 * state.url: /code
                 * state.root.fragment: null
                 */
                const urlContainsCode = this.includesCode(state.url);
                const fragmentContainsCode = !!state.root &&
                    !!state.root.fragment &&
                    this.includesCode(`#${state.root.fragment}`);
                const hashRouting = this.location.prepareExternalUrl(state.url).indexOf('#') === 0;
                // Ensure code parameter is in fragment (and not in query parameter), or that hash hash routing is used
                if (urlContainsCode && (fragmentContainsCode || hashRouting)) {
                    this.authService
                        .getLogger()
                        .info('Guard - Hash contains known code response, stopping navigation.');
                    // Path routing (navigate to current path without hash)
                    if (currentPath.indexOf('#') > -1) {
                        return of(this.parseUrl(this.location.path()));
                    }
                    // Hash routing (navigate to root path)
                    return of(this.parseUrl(''));
                }
            }
            return of(true);
        }), catchError((error) => {
            this.authService
                .getLogger()
                .error('Guard - error while logging in, unable to activate');
            this.authService
                .getLogger()
                .errorPii(`Guard - error: ${error.message}`);
            /**
             * If a loginFailedRoute is set, checks to see if state is passed before returning route
             */
            if (this.loginFailedRoute && state) {
                this.authService
                    .getLogger()
                    .verbose('Guard - loginFailedRoute set, redirecting');
                return of(this.loginFailedRoute);
            }
            return of(false);
        }));
    }
    includesCode(path) {
        return ((path.lastIndexOf('/code') > -1 &&
            path.lastIndexOf('/code') === path.length - '/code'.length) || // path.endsWith("/code")
            path.indexOf('#code=') > -1 ||
            path.indexOf('&code=') > -1);
    }
    canActivate(route, state) {
        this.authService.getLogger().verbose('Guard - canActivate');
        return this.activateHelper(state);
    }
    canActivateChild(route, state) {
        this.authService.getLogger().verbose('Guard - canActivateChild');
        return this.activateHelper(state);
    }
    canMatch() {
        this.authService.getLogger().verbose('Guard - canLoad');
        return this.activateHelper();
    }
}
MsalGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalGuard, deps: [{ token: MSAL_GUARD_CONFIG }, { token: i1.MsalBroadcastService }, { token: i2.MsalService }, { token: i3.Location }, { token: i4.Router }], target: i0.ɵɵFactoryTarget.Injectable });
MsalGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalGuard });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.7", ngImport: i0, type: MsalGuard, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MSAL_GUARD_CONFIG]
                }] }, { type: i1.MsalBroadcastService }, { type: i2.MsalService }, { type: i3.Location }, { type: i4.Router }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNhbC5ndWFyZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tc2FsLmd1YXJkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUVILE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBUW5ELE9BQU8sRUFDTCxlQUFlLEVBQ2YsNkJBQTZCLEVBQzdCLFlBQVksRUFDWixTQUFTLEdBSVYsTUFBTSxxQkFBcUIsQ0FBQztBQUM3QixPQUFPLEVBQWMsRUFBRSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3RDLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBSTVELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLGFBQWEsQ0FBQzs7Ozs7O0FBR2hELE1BQU0sT0FBTyxTQUFTO0lBR3BCLFlBQ3FDLGVBQXVDLEVBQ2xFLG9CQUEwQyxFQUMxQyxXQUF3QixFQUN4QixRQUFrQixFQUNsQixNQUFjO1FBSmEsb0JBQWUsR0FBZixlQUFlLENBQXdCO1FBQ2xFLHlCQUFvQixHQUFwQixvQkFBb0IsQ0FBc0I7UUFDMUMsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFDeEIsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixXQUFNLEdBQU4sTUFBTSxDQUFRO1FBRXRCLHFFQUFxRTtRQUNyRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3BELENBQUM7SUFFRDs7O09BR0c7SUFDSCxRQUFRLENBQUMsR0FBVztRQUNsQixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsaUJBQWlCLENBQUMsSUFBWTtRQUM1QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQ3hFLHdGQUF3RjtRQUN4RixNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0QsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQ3JDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUNwRSxDQUFDO1FBRUYsdURBQXVEO1FBQ3ZELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdkQseUJBQXlCO1FBQ3pCLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUMzQixJQUFJLENBQUMsV0FBVztpQkFDYixTQUFTLEVBQUU7aUJBQ1gsT0FBTyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7WUFDbEQsT0FBTyxHQUFHLE9BQU8sSUFBSSxPQUFPLEVBQUUsQ0FBQztTQUNoQztRQUVEOzs7V0FHRztRQUNILE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSSxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7T0FHRztJQUNLLGtCQUFrQixDQUFDLEtBQTBCO1FBQ25ELE1BQU0sV0FBVyxHQUNmLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEtBQUssVUFBVTtZQUNwRCxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUM7WUFDM0QsQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzlDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEtBQUssZUFBZSxDQUFDLEtBQUssRUFBRTtZQUNsRSxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1lBQ3BFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsV0FBMkIsQ0FBQyxDQUFDLElBQUksQ0FDbEUsR0FBRyxDQUFDLENBQUMsUUFBOEIsRUFBRSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsV0FBVztxQkFDYixTQUFTLEVBQUU7cUJBQ1gsT0FBTyxDQUNOLHlFQUF5RSxDQUMxRSxDQUFDO2dCQUNKLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDN0QsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDLENBQUMsQ0FDSCxDQUFDO1NBQ0g7UUFFRCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1FBQ3ZFLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1RCxPQUFPLElBQUksQ0FBQyxXQUFXO2FBQ3BCLGFBQWEsQ0FBQztZQUNiLGlCQUFpQjtZQUNqQixHQUFHLFdBQVc7U0FDSSxDQUFDO2FBQ3BCLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssY0FBYyxDQUNwQixLQUEyQjtRQUUzQixJQUNFLElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxLQUFLLGVBQWUsQ0FBQyxLQUFLO1lBQzlELElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxLQUFLLGVBQWUsQ0FBQyxRQUFRLEVBQ2pFO1lBQ0EsTUFBTSxJQUFJLDZCQUE2QixDQUNyQywwQkFBMEIsRUFDMUIsbUpBQW1KLENBQ3BKLENBQUM7U0FDSDtRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFFN0Q7OztXQUdHO1FBQ0gsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFDRSxTQUFTLENBQUMsMkJBQTJCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0JBQzNELFlBQVksQ0FBQyxVQUFVLEVBQUU7Z0JBQ3pCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNO3FCQUNqRCxxQkFBcUIsRUFDeEI7Z0JBQ0EsSUFBSSxDQUFDLFdBQVc7cUJBQ2IsU0FBUyxFQUFFO3FCQUNYLE9BQU8sQ0FDTixtSUFBbUksQ0FDcEksQ0FBQztnQkFDSixPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNsQjtTQUNGO2FBQU07WUFDTCxJQUFJLENBQUMsV0FBVztpQkFDYixTQUFTLEVBQUU7aUJBQ1gsSUFBSSxDQUNILGtGQUFrRixDQUNuRixDQUFDO1lBQ0osT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakI7UUFFRDs7V0FFRztRQUNILElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRTtZQUN6QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FDbkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FDdEMsQ0FBQztTQUNIO1FBRUQsMEVBQTBFO1FBQzFFLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTdDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQ3ZDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDYixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUNyRCxDQUFDLENBQUMsRUFDRixTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxDQUFDLE1BQU0sRUFBRTtnQkFDdEQsSUFBSSxLQUFLLEVBQUU7b0JBQ1QsSUFBSSxDQUFDLFdBQVc7eUJBQ2IsU0FBUyxFQUFFO3lCQUNYLE9BQU8sQ0FDTiw0REFBNEQsQ0FDN0QsQ0FBQztvQkFDSixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDdkM7Z0JBQ0QsSUFBSSxDQUFDLFdBQVc7cUJBQ2IsU0FBUyxFQUFFO3FCQUNYLE9BQU8sQ0FBQyxzREFBc0QsQ0FBQyxDQUFDO2dCQUNuRSxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNsQjtZQUVELElBQUksQ0FBQyxXQUFXO2lCQUNiLFNBQVMsRUFBRTtpQkFDWCxPQUFPLENBQUMseURBQXlELENBQUMsQ0FBQztZQUV0RSxrREFBa0Q7WUFDbEQsSUFBSSxLQUFLLEVBQUU7Z0JBQ1Q7Ozs7bUJBSUc7Z0JBRUg7Ozs7bUJBSUc7Z0JBQ0gsTUFBTSxlQUFlLEdBQVksSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzlELE1BQU0sb0JBQW9CLEdBQ3hCLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSTtvQkFDWixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRO29CQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUMvQyxNQUFNLFdBQVcsR0FDZixJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUVqRSx1R0FBdUc7Z0JBQ3ZHLElBQUksZUFBZSxJQUFJLENBQUMsb0JBQW9CLElBQUksV0FBVyxDQUFDLEVBQUU7b0JBQzVELElBQUksQ0FBQyxXQUFXO3lCQUNiLFNBQVMsRUFBRTt5QkFDWCxJQUFJLENBQ0gsaUVBQWlFLENBQ2xFLENBQUM7b0JBRUosdURBQXVEO29CQUN2RCxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7d0JBQ2pDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQ2hEO29CQUVELHVDQUF1QztvQkFDdkMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2lCQUM5QjthQUNGO1lBRUQsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbEIsQ0FBQyxDQUFDLEVBQ0YsVUFBVSxDQUFDLENBQUMsS0FBWSxFQUFFLEVBQUU7WUFDMUIsSUFBSSxDQUFDLFdBQVc7aUJBQ2IsU0FBUyxFQUFFO2lCQUNYLEtBQUssQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxXQUFXO2lCQUNiLFNBQVMsRUFBRTtpQkFDWCxRQUFRLENBQUMsa0JBQWtCLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQy9DOztlQUVHO1lBQ0gsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLElBQUksS0FBSyxFQUFFO2dCQUNsQyxJQUFJLENBQUMsV0FBVztxQkFDYixTQUFTLEVBQUU7cUJBQ1gsT0FBTyxDQUFDLDJDQUEyQyxDQUFDLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2FBQ2xDO1lBQ0QsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBWTtRQUN2QixPQUFPLENBQ0wsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLHlCQUF5QjtZQUMxRixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUM1QixDQUFDO0lBQ0osQ0FBQztJQUVELFdBQVcsQ0FDVCxLQUE2QixFQUM3QixLQUEwQjtRQUUxQixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1FBQzVELE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsZ0JBQWdCLENBQ2QsS0FBNkIsRUFDN0IsS0FBMEI7UUFFMUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQztRQUNqRSxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELFFBQVE7UUFDTixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3hELE9BQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQy9CLENBQUM7O3NHQWxRVSxTQUFTLGtCQUlWLGlCQUFpQjswR0FKaEIsU0FBUzsyRkFBVCxTQUFTO2tCQURyQixVQUFVOzswQkFLTixNQUFNOzJCQUFDLGlCQUFpQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBJbmplY3RhYmxlLCBJbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7XG4gIEFjdGl2YXRlZFJvdXRlU25hcHNob3QsXG4gIFJvdXRlclN0YXRlU25hcHNob3QsXG4gIFVybFRyZWUsXG4gIFJvdXRlcixcbn0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7XG4gIEludGVyYWN0aW9uVHlwZSxcbiAgQnJvd3NlckNvbmZpZ3VyYXRpb25BdXRoRXJyb3IsXG4gIEJyb3dzZXJVdGlscyxcbiAgVXJsU3RyaW5nLFxuICBQb3B1cFJlcXVlc3QsXG4gIFJlZGlyZWN0UmVxdWVzdCxcbiAgQXV0aGVudGljYXRpb25SZXN1bHQsXG59IGZyb20gJ0BhenVyZS9tc2FsLWJyb3dzZXInO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGNvbmNhdE1hcCwgY2F0Y2hFcnJvciwgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgTXNhbFNlcnZpY2UgfSBmcm9tICcuL21zYWwuc2VydmljZSc7XG5pbXBvcnQgeyBNc2FsR3VhcmRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9tc2FsLmd1YXJkLmNvbmZpZyc7XG5pbXBvcnQgeyBNc2FsQnJvYWRjYXN0U2VydmljZSB9IGZyb20gJy4vbXNhbC5icm9hZGNhc3Quc2VydmljZSc7XG5pbXBvcnQgeyBNU0FMX0dVQVJEX0NPTkZJRyB9IGZyb20gJy4vY29uc3RhbnRzJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIE1zYWxHdWFyZCB7XG4gIHByaXZhdGUgbG9naW5GYWlsZWRSb3V0ZT86IFVybFRyZWU7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgQEluamVjdChNU0FMX0dVQVJEX0NPTkZJRykgcHJpdmF0ZSBtc2FsR3VhcmRDb25maWc6IE1zYWxHdWFyZENvbmZpZ3VyYXRpb24sXG4gICAgcHJpdmF0ZSBtc2FsQnJvYWRjYXN0U2VydmljZTogTXNhbEJyb2FkY2FzdFNlcnZpY2UsXG4gICAgcHJpdmF0ZSBhdXRoU2VydmljZTogTXNhbFNlcnZpY2UsXG4gICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlclxuICApIHtcbiAgICAvLyBTdWJzY3JpYmluZyBzbyBldmVudHMgaW4gTXNhbEd1YXJkIHdpbGwgc2V0IGluUHJvZ3Jlc3MkIG9ic2VydmFibGVcbiAgICB0aGlzLm1zYWxCcm9hZGNhc3RTZXJ2aWNlLmluUHJvZ3Jlc3MkLnN1YnNjcmliZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFBhcnNlcyB1cmwgc3RyaW5nIHRvIFVybFRyZWVcbiAgICogQHBhcmFtIHVybFxuICAgKi9cbiAgcGFyc2VVcmwodXJsOiBzdHJpbmcpOiBVcmxUcmVlIHtcbiAgICByZXR1cm4gdGhpcy5yb3V0ZXIucGFyc2VVcmwodXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgdGhlIGFic29sdXRlIHVybCBmb3IgdGhlIGRlc3RpbmF0aW9uIHBhZ2VcbiAgICogQHBhcmFtIHBhdGggUmVsYXRpdmUgcGF0aCBvZiByZXF1ZXN0ZWQgcGFnZVxuICAgKiBAcmV0dXJucyBGdWxsIGRlc3RpbmF0aW9uIHVybFxuICAgKi9cbiAgZ2V0RGVzdGluYXRpb25VcmwocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICB0aGlzLmF1dGhTZXJ2aWNlLmdldExvZ2dlcigpLnZlcmJvc2UoJ0d1YXJkIC0gZ2V0dGluZyBkZXN0aW5hdGlvbiB1cmwnKTtcbiAgICAvLyBBYnNvbHV0ZSBiYXNlIHVybCBmb3IgdGhlIGFwcGxpY2F0aW9uIChkZWZhdWx0IHRvIG9yaWdpbiBpZiBiYXNlIGVsZW1lbnQgbm90IHByZXNlbnQpXG4gICAgY29uc3QgYmFzZUVsZW1lbnRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2Jhc2UnKTtcbiAgICBjb25zdCBiYXNlVXJsID0gdGhpcy5sb2NhdGlvbi5ub3JtYWxpemUoXG4gICAgICBiYXNlRWxlbWVudHMubGVuZ3RoID8gYmFzZUVsZW1lbnRzWzBdLmhyZWYgOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luXG4gICAgKTtcblxuICAgIC8vIFBhdGggb2YgcGFnZSAoaW5jbHVkaW5nIGhhc2gsIGlmIHVzaW5nIGhhc2ggcm91dGluZylcbiAgICBjb25zdCBwYXRoVXJsID0gdGhpcy5sb2NhdGlvbi5wcmVwYXJlRXh0ZXJuYWxVcmwocGF0aCk7XG5cbiAgICAvLyBIYXNoIGxvY2F0aW9uIHN0cmF0ZWd5XG4gICAgaWYgKHBhdGhVcmwuc3RhcnRzV2l0aCgnIycpKSB7XG4gICAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAgIC5nZXRMb2dnZXIoKVxuICAgICAgICAudmVyYm9zZSgnR3VhcmQgLSBkZXN0aW5hdGlvbiBieSBoYXNoIHJvdXRpbmcnKTtcbiAgICAgIHJldHVybiBgJHtiYXNlVXJsfS8ke3BhdGhVcmx9YDtcbiAgICB9XG5cbiAgICAvKlxuICAgICAqIElmIHVzaW5nIHBhdGggbG9jYXRpb24gc3RyYXRlZ3ksIHBhdGhVcmwgd2lsbCBpbmNsdWRlIHRoZSByZWxhdGl2ZSBwb3J0aW9uIG9mIHRoZSBiYXNlIHBhdGggKGUuZy4gL2Jhc2UvcGFnZSkuXG4gICAgICogU2luY2UgYmFzZVVybCBhbHNvIGluY2x1ZGVzIC9iYXNlLCBjYW4ganVzdCBjb25jYXRlbnRhdGUgYmFzZVVybCArIHBhdGhcbiAgICAgKi9cbiAgICByZXR1cm4gYCR7YmFzZVVybH0ke3BhdGh9YDtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbnRlcmFjdGl2ZWx5IHByb21wdCB0aGUgdXNlciB0byBsb2dpblxuICAgKiBAcGFyYW0gdXJsIFBhdGggb2YgdGhlIHJlcXVlc3RlZCBwYWdlXG4gICAqL1xuICBwcml2YXRlIGxvZ2luSW50ZXJhY3RpdmVseShzdGF0ZTogUm91dGVyU3RhdGVTbmFwc2hvdCk6IE9ic2VydmFibGU8Ym9vbGVhbj4ge1xuICAgIGNvbnN0IGF1dGhSZXF1ZXN0ID1cbiAgICAgIHR5cGVvZiB0aGlzLm1zYWxHdWFyZENvbmZpZy5hdXRoUmVxdWVzdCA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICA/IHRoaXMubXNhbEd1YXJkQ29uZmlnLmF1dGhSZXF1ZXN0KHRoaXMuYXV0aFNlcnZpY2UsIHN0YXRlKVxuICAgICAgICA6IHsgLi4udGhpcy5tc2FsR3VhcmRDb25maWcuYXV0aFJlcXVlc3QgfTtcbiAgICBpZiAodGhpcy5tc2FsR3VhcmRDb25maWcuaW50ZXJhY3Rpb25UeXBlID09PSBJbnRlcmFjdGlvblR5cGUuUG9wdXApIHtcbiAgICAgIHRoaXMuYXV0aFNlcnZpY2UuZ2V0TG9nZ2VyKCkudmVyYm9zZSgnR3VhcmQgLSBsb2dnaW5nIGluIGJ5IHBvcHVwJyk7XG4gICAgICByZXR1cm4gdGhpcy5hdXRoU2VydmljZS5sb2dpblBvcHVwKGF1dGhSZXF1ZXN0IGFzIFBvcHVwUmVxdWVzdCkucGlwZShcbiAgICAgICAgbWFwKChyZXNwb25zZTogQXV0aGVudGljYXRpb25SZXN1bHQpID0+IHtcbiAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAgICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgICAgICAgIC52ZXJib3NlKFxuICAgICAgICAgICAgICAnR3VhcmQgLSBsb2dpbiBieSBwb3B1cCBzdWNjZXNzZnVsLCBjYW4gYWN0aXZhdGUsIHNldHRpbmcgYWN0aXZlIGFjY291bnQnXG4gICAgICAgICAgICApO1xuICAgICAgICAgIHRoaXMuYXV0aFNlcnZpY2UuaW5zdGFuY2Uuc2V0QWN0aXZlQWNjb3VudChyZXNwb25zZS5hY2NvdW50KTtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfVxuXG4gICAgdGhpcy5hdXRoU2VydmljZS5nZXRMb2dnZXIoKS52ZXJib3NlKCdHdWFyZCAtIGxvZ2dpbmcgaW4gYnkgcmVkaXJlY3QnKTtcbiAgICBjb25zdCByZWRpcmVjdFN0YXJ0UGFnZSA9IHRoaXMuZ2V0RGVzdGluYXRpb25Vcmwoc3RhdGUudXJsKTtcbiAgICByZXR1cm4gdGhpcy5hdXRoU2VydmljZVxuICAgICAgLmxvZ2luUmVkaXJlY3Qoe1xuICAgICAgICByZWRpcmVjdFN0YXJ0UGFnZSxcbiAgICAgICAgLi4uYXV0aFJlcXVlc3QsXG4gICAgICB9IGFzIFJlZGlyZWN0UmVxdWVzdClcbiAgICAgIC5waXBlKG1hcCgoKSA9PiBmYWxzZSkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEhlbHBlciB3aGljaCBjaGVja3MgZm9yIHRoZSBjb3JyZWN0IGludGVyYWN0aW9uIHR5cGUsIHByZXZlbnRzIHBhZ2Ugd2l0aCBHdWFyZCB0byBiZSBzZXQgYXMgcmVkaXJlY3QsIGFuZCBjYWxscyBoYW5kbGVSZWRpcmVjdE9ic2VydmFibGVcbiAgICogQHBhcmFtIHN0YXRlXG4gICAqL1xuICBwcml2YXRlIGFjdGl2YXRlSGVscGVyKFxuICAgIHN0YXRlPzogUm91dGVyU3RhdGVTbmFwc2hvdFxuICApOiBPYnNlcnZhYmxlPGJvb2xlYW4gfCBVcmxUcmVlPiB7XG4gICAgaWYgKFxuICAgICAgdGhpcy5tc2FsR3VhcmRDb25maWcuaW50ZXJhY3Rpb25UeXBlICE9PSBJbnRlcmFjdGlvblR5cGUuUG9wdXAgJiZcbiAgICAgIHRoaXMubXNhbEd1YXJkQ29uZmlnLmludGVyYWN0aW9uVHlwZSAhPT0gSW50ZXJhY3Rpb25UeXBlLlJlZGlyZWN0XG4gICAgKSB7XG4gICAgICB0aHJvdyBuZXcgQnJvd3NlckNvbmZpZ3VyYXRpb25BdXRoRXJyb3IoXG4gICAgICAgICdpbnZhbGlkX2ludGVyYWN0aW9uX3R5cGUnLFxuICAgICAgICAnSW52YWxpZCBpbnRlcmFjdGlvbiB0eXBlIHByb3ZpZGVkIHRvIE1TQUwgR3VhcmQuIEludGVyYWN0aW9uVHlwZS5Qb3B1cCBvciBJbnRlcmFjdGlvblR5cGUuUmVkaXJlY3QgbXVzdCBiZSBwcm92aWRlZCBpbiB0aGUgTXNhbEd1YXJkQ29uZmlndXJhdGlvbidcbiAgICAgICk7XG4gICAgfVxuICAgIHRoaXMuYXV0aFNlcnZpY2UuZ2V0TG9nZ2VyKCkudmVyYm9zZSgnTVNBTCBHdWFyZCBhY3RpdmF0ZWQnKTtcblxuICAgIC8qXG4gICAgICogSWYgYSBwYWdlIHdpdGggTVNBTCBHdWFyZCBpcyBzZXQgYXMgdGhlIHJlZGlyZWN0IGZvciBhY3F1aXJlVG9rZW5TaWxlbnQsXG4gICAgICogc2hvcnQtY2lyY3VpdCB0byBwcmV2ZW50IHJlZGlyZWN0aW5nIG9yIHBvcHVwcy5cbiAgICAgKi9cbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIGlmIChcbiAgICAgICAgVXJsU3RyaW5nLmhhc2hDb250YWluc0tub3duUHJvcGVydGllcyh3aW5kb3cubG9jYXRpb24uaGFzaCkgJiZcbiAgICAgICAgQnJvd3NlclV0aWxzLmlzSW5JZnJhbWUoKSAmJlxuICAgICAgICAhdGhpcy5hdXRoU2VydmljZS5pbnN0YW5jZS5nZXRDb25maWd1cmF0aW9uKCkuc3lzdGVtXG4gICAgICAgICAgLmFsbG93UmVkaXJlY3RJbklmcmFtZVxuICAgICAgKSB7XG4gICAgICAgIHRoaXMuYXV0aFNlcnZpY2VcbiAgICAgICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgICAgICAud2FybmluZyhcbiAgICAgICAgICAgICdHdWFyZCAtIHJlZGlyZWN0VXJpIHNldCB0byBwYWdlIHdpdGggTVNBTCBHdWFyZC4gSXQgaXMgcmVjb21tZW5kZWQgdG8gbm90IHNldCByZWRpcmVjdFVyaSB0byBhIHBhZ2UgdGhhdCByZXF1aXJlcyBhdXRoZW50aWNhdGlvbi4nXG4gICAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIG9mKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5hdXRoU2VydmljZVxuICAgICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgICAgLmluZm8oXG4gICAgICAgICAgJ0d1YXJkIC0gd2luZG93IGlzIHVuZGVmaW5lZCwgTVNBTCBkb2VzIG5vdCBzdXBwb3J0IHNlcnZlci1zaWRlIHRva2VuIGFjcXVpc2l0aW9uJ1xuICAgICAgICApO1xuICAgICAgcmV0dXJuIG9mKHRydWUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIElmIGEgbG9naW5GYWlsZWRSb3V0ZSBpcyBzZXQgaW4gdGhlIGNvbmZpZywgc2V0IHRoaXMgYXMgdGhlIGxvZ2luRmFpbGVkUm91dGVcbiAgICAgKi9cbiAgICBpZiAodGhpcy5tc2FsR3VhcmRDb25maWcubG9naW5GYWlsZWRSb3V0ZSkge1xuICAgICAgdGhpcy5sb2dpbkZhaWxlZFJvdXRlID0gdGhpcy5wYXJzZVVybChcbiAgICAgICAgdGhpcy5tc2FsR3VhcmRDb25maWcubG9naW5GYWlsZWRSb3V0ZVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBDYXB0dXJlIGN1cnJlbnQgcGF0aCBiZWZvcmUgaXQgZ2V0cyBjaGFuZ2VkIGJ5IGhhbmRsZVJlZGlyZWN0T2JzZXJ2YWJsZVxuICAgIGNvbnN0IGN1cnJlbnRQYXRoID0gdGhpcy5sb2NhdGlvbi5wYXRoKHRydWUpO1xuXG4gICAgcmV0dXJuIHRoaXMuYXV0aFNlcnZpY2UuaW5pdGlhbGl6ZSgpLnBpcGUoXG4gICAgICBjb25jYXRNYXAoKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5hdXRoU2VydmljZS5oYW5kbGVSZWRpcmVjdE9ic2VydmFibGUoKTtcbiAgICAgIH0pLFxuICAgICAgY29uY2F0TWFwKCgpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLmF1dGhTZXJ2aWNlLmluc3RhbmNlLmdldEFsbEFjY291bnRzKCkubGVuZ3RoKSB7XG4gICAgICAgICAgaWYgKHN0YXRlKSB7XG4gICAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAgICAgICAgIC5nZXRMb2dnZXIoKVxuICAgICAgICAgICAgICAudmVyYm9zZShcbiAgICAgICAgICAgICAgICAnR3VhcmQgLSBubyBhY2NvdW50cyByZXRyaWV2ZWQsIGxvZyBpbiByZXF1aXJlZCB0byBhY3RpdmF0ZSdcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxvZ2luSW50ZXJhY3RpdmVseShzdGF0ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuYXV0aFNlcnZpY2VcbiAgICAgICAgICAgIC5nZXRMb2dnZXIoKVxuICAgICAgICAgICAgLnZlcmJvc2UoJ0d1YXJkIC0gbm8gYWNjb3VudHMgcmV0cmlldmVkLCBubyBzdGF0ZSwgY2Fubm90IGxvYWQnKTtcbiAgICAgICAgICByZXR1cm4gb2YoZmFsc2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5hdXRoU2VydmljZVxuICAgICAgICAgIC5nZXRMb2dnZXIoKVxuICAgICAgICAgIC52ZXJib3NlKCdHdWFyZCAtIGF0IGxlYXN0IDEgYWNjb3VudCBleGlzdHMsIGNhbiBhY3RpdmF0ZSBvciBsb2FkJyk7XG5cbiAgICAgICAgLy8gUHJldmVudCBuYXZpZ2F0aW5nIHRoZSBhcHAgdG8gLyNjb2RlPSBvciAvY29kZT1cbiAgICAgICAgaWYgKHN0YXRlKSB7XG4gICAgICAgICAgLypcbiAgICAgICAgICAgKiBQYXRoIHJvdXRpbmc6XG4gICAgICAgICAgICogc3RhdGUudXJsOiAvI2NvZGU9Li4uXG4gICAgICAgICAgICogc3RhdGUucm9vdC5mcmFnbWVudDogY29kZT0uLi5cbiAgICAgICAgICAgKi9cblxuICAgICAgICAgIC8qXG4gICAgICAgICAgICogSGFzaCByb3V0aW5nOlxuICAgICAgICAgICAqIHN0YXRlLnVybDogL2NvZGVcbiAgICAgICAgICAgKiBzdGF0ZS5yb290LmZyYWdtZW50OiBudWxsXG4gICAgICAgICAgICovXG4gICAgICAgICAgY29uc3QgdXJsQ29udGFpbnNDb2RlOiBib29sZWFuID0gdGhpcy5pbmNsdWRlc0NvZGUoc3RhdGUudXJsKTtcbiAgICAgICAgICBjb25zdCBmcmFnbWVudENvbnRhaW5zQ29kZTogYm9vbGVhbiA9XG4gICAgICAgICAgICAhIXN0YXRlLnJvb3QgJiZcbiAgICAgICAgICAgICEhc3RhdGUucm9vdC5mcmFnbWVudCAmJlxuICAgICAgICAgICAgdGhpcy5pbmNsdWRlc0NvZGUoYCMke3N0YXRlLnJvb3QuZnJhZ21lbnR9YCk7XG4gICAgICAgICAgY29uc3QgaGFzaFJvdXRpbmc6IGJvb2xlYW4gPVxuICAgICAgICAgICAgdGhpcy5sb2NhdGlvbi5wcmVwYXJlRXh0ZXJuYWxVcmwoc3RhdGUudXJsKS5pbmRleE9mKCcjJykgPT09IDA7XG5cbiAgICAgICAgICAvLyBFbnN1cmUgY29kZSBwYXJhbWV0ZXIgaXMgaW4gZnJhZ21lbnQgKGFuZCBub3QgaW4gcXVlcnkgcGFyYW1ldGVyKSwgb3IgdGhhdCBoYXNoIGhhc2ggcm91dGluZyBpcyB1c2VkXG4gICAgICAgICAgaWYgKHVybENvbnRhaW5zQ29kZSAmJiAoZnJhZ21lbnRDb250YWluc0NvZGUgfHwgaGFzaFJvdXRpbmcpKSB7XG4gICAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAgICAgICAgIC5nZXRMb2dnZXIoKVxuICAgICAgICAgICAgICAuaW5mbyhcbiAgICAgICAgICAgICAgICAnR3VhcmQgLSBIYXNoIGNvbnRhaW5zIGtub3duIGNvZGUgcmVzcG9uc2UsIHN0b3BwaW5nIG5hdmlnYXRpb24uJ1xuICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAvLyBQYXRoIHJvdXRpbmcgKG5hdmlnYXRlIHRvIGN1cnJlbnQgcGF0aCB3aXRob3V0IGhhc2gpXG4gICAgICAgICAgICBpZiAoY3VycmVudFBhdGguaW5kZXhPZignIycpID4gLTEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG9mKHRoaXMucGFyc2VVcmwodGhpcy5sb2NhdGlvbi5wYXRoKCkpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gSGFzaCByb3V0aW5nIChuYXZpZ2F0ZSB0byByb290IHBhdGgpXG4gICAgICAgICAgICByZXR1cm4gb2YodGhpcy5wYXJzZVVybCgnJykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBvZih0cnVlKTtcbiAgICAgIH0pLFxuICAgICAgY2F0Y2hFcnJvcigoZXJyb3I6IEVycm9yKSA9PiB7XG4gICAgICAgIHRoaXMuYXV0aFNlcnZpY2VcbiAgICAgICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgICAgICAuZXJyb3IoJ0d1YXJkIC0gZXJyb3Igd2hpbGUgbG9nZ2luZyBpbiwgdW5hYmxlIHRvIGFjdGl2YXRlJyk7XG4gICAgICAgIHRoaXMuYXV0aFNlcnZpY2VcbiAgICAgICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgICAgICAuZXJyb3JQaWkoYEd1YXJkIC0gZXJyb3I6ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIElmIGEgbG9naW5GYWlsZWRSb3V0ZSBpcyBzZXQsIGNoZWNrcyB0byBzZWUgaWYgc3RhdGUgaXMgcGFzc2VkIGJlZm9yZSByZXR1cm5pbmcgcm91dGVcbiAgICAgICAgICovXG4gICAgICAgIGlmICh0aGlzLmxvZ2luRmFpbGVkUm91dGUgJiYgc3RhdGUpIHtcbiAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAgICAgICAuZ2V0TG9nZ2VyKClcbiAgICAgICAgICAgIC52ZXJib3NlKCdHdWFyZCAtIGxvZ2luRmFpbGVkUm91dGUgc2V0LCByZWRpcmVjdGluZycpO1xuICAgICAgICAgIHJldHVybiBvZih0aGlzLmxvZ2luRmFpbGVkUm91dGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvZihmYWxzZSk7XG4gICAgICB9KVxuICAgICk7XG4gIH1cblxuICBpbmNsdWRlc0NvZGUocGF0aDogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIChcbiAgICAgIChwYXRoLmxhc3RJbmRleE9mKCcvY29kZScpID4gLTEgJiZcbiAgICAgICAgcGF0aC5sYXN0SW5kZXhPZignL2NvZGUnKSA9PT0gcGF0aC5sZW5ndGggLSAnL2NvZGUnLmxlbmd0aCkgfHwgLy8gcGF0aC5lbmRzV2l0aChcIi9jb2RlXCIpXG4gICAgICBwYXRoLmluZGV4T2YoJyNjb2RlPScpID4gLTEgfHxcbiAgICAgIHBhdGguaW5kZXhPZignJmNvZGU9JykgPiAtMVxuICAgICk7XG4gIH1cblxuICBjYW5BY3RpdmF0ZShcbiAgICByb3V0ZTogQWN0aXZhdGVkUm91dGVTbmFwc2hvdCxcbiAgICBzdGF0ZTogUm91dGVyU3RhdGVTbmFwc2hvdFxuICApOiBPYnNlcnZhYmxlPGJvb2xlYW4gfCBVcmxUcmVlPiB7XG4gICAgdGhpcy5hdXRoU2VydmljZS5nZXRMb2dnZXIoKS52ZXJib3NlKCdHdWFyZCAtIGNhbkFjdGl2YXRlJyk7XG4gICAgcmV0dXJuIHRoaXMuYWN0aXZhdGVIZWxwZXIoc3RhdGUpO1xuICB9XG5cbiAgY2FuQWN0aXZhdGVDaGlsZChcbiAgICByb3V0ZTogQWN0aXZhdGVkUm91dGVTbmFwc2hvdCxcbiAgICBzdGF0ZTogUm91dGVyU3RhdGVTbmFwc2hvdFxuICApOiBPYnNlcnZhYmxlPGJvb2xlYW4gfCBVcmxUcmVlPiB7XG4gICAgdGhpcy5hdXRoU2VydmljZS5nZXRMb2dnZXIoKS52ZXJib3NlKCdHdWFyZCAtIGNhbkFjdGl2YXRlQ2hpbGQnKTtcbiAgICByZXR1cm4gdGhpcy5hY3RpdmF0ZUhlbHBlcihzdGF0ZSk7XG4gIH1cblxuICBjYW5NYXRjaCgpOiBPYnNlcnZhYmxlPGJvb2xlYW4gfCBVcmxUcmVlPiB7XG4gICAgdGhpcy5hdXRoU2VydmljZS5nZXRMb2dnZXIoKS52ZXJib3NlKCdHdWFyZCAtIGNhbkxvYWQnKTtcbiAgICByZXR1cm4gdGhpcy5hY3RpdmF0ZUhlbHBlcigpO1xuICB9XG59XG4iXX0=